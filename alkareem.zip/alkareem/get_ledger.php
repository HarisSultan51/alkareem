<?php 
error_reporting(0);
include "includes/session.php";
include "includes/config.php";
session_start();
if(isset($_SESSION['adminid'])){


}
else{
   header('Location: login.php'); 
}?>
 <?php 
$vendor_id = $_POST['vendors'];

$f_date = $_POST['f_date'];
$t_date = $_POST['t_date'];
// print_r($_POST);
// exit();
  // echo $u_id;exit();  




   ?>
<html lang="en" >
<link rel="icon" href="favicon.ico" type="image/x-icon"><!-- VENDOR CSS -->
<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

<!-- MAIN CSS -->
<link rel="stylesheet" href="assets_light/css/main.css">
<link rel="stylesheet" href="assets_light/css/color_skins.css">

<body >

            <div class="row clearfix" >
                <div class="col-lg-12 col-md-12">
                    <div class="card invoice1">                        
                        <div class="body">
                            <?php 
                        
                         error_reporting(0);
                        $sql=mysqli_query($conn, "SELECT * FROM tbl_company ");
                        $data=mysqli_fetch_assoc($sql);
                        $c_name = $data['c_name'];
                        $c_address = $data['c_address'];
                        $c_phone = $data['c_phone'];
                        $c_mobile = $data['c_mobile'];
                        $image = $data['user_profile'];
                        
                      
                        ?>
                        <div class="row">
                            <div class="invoice-top clearfix col-md-12 text-center">

                                <div class="logo" style='width: 7%;'>
                                    <img src="<?php echo $image; ?>"  alt="user" class="img-fluid">
                                </div>
                                <div class="info text-center col-md-12" style="margin-top: 1%;" >
                                    <h1 ><?php echo $c_name;?></h1>
                                    <h3 class="text-center">All Account Ledger</h3>

                                  
                                </div>

                            </div>
                              </div>
                                      <div class="row">
                            <div class="clearfix col-md-12" >
                                <div class="info text-center col-md-12"  >
                                   <p>(<?php echo $c_address;?>)<br><?php echo $c_phone;?></p>
                               </div> </div>
                              </div>
                              <div class="row">
                                   <div class="clearfix text-left col-md-6" >
                                   
                                    
                                </span></div> 
                            <div class="clearfix text-right col-md-6" >

                            <span > <b>FROM DATE/TO DATE : </b> <?php echo $f_date.'/'.$t_date;?>
                       </span></div> </div>
                        <?php 
              
                        if($vendor_id=='All'){

                            $username = 'All';
                            $where_ledger = "";
                        }else{
                            if($vendor_id=='All'){
                             $where_ledger = "";  
                            }else{

                            $len=strlen($vendor_id);
                        
                            if($len=='6')
                            {
                               
                              $where_ledger = "where left(acode,6) = $vendor_id";  
                            }
                            else
                            {

                                $where_ledger = "where acode = $vendor_id";
                            }
                            
                        }
                  
                        $sql="SELECT acode,aname FROM tbl_account UNION SELECT acode,aname FROM tbl_account_lv2 $where_ledger ";

                        $vendsql=mysqli_query($conn, $sql);
                        $detail = mysqli_fetch_assoc($vendsql);
                        $username =$detail['aname'];
                          
                        // print_r($sql);   
                        }


                     
                      
                        ?>
                       
                            
                       
             

                               
                            <hr> 
                                              <div class="row clearfix">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                 <table id="example" class="display" style="width:100%">
                                                    <thead class="thead-dark">
                                                        <tr>
                                                                                         
                                                                                                 
                                                                       
                                                            <th>ID</th>
                                                            <th>Account</th>
                                                            <th>Invoice</th>
                                                            <th>Narration</th>
                                                            <th style="width: 10%;">Dr</th>
                                                            <th style="width: 10%;">Cr</th>
                                                            <!-- <th >CNIC</th> -->
                                                       
                                                            <!-- <th >Account Balance</th> -->
                                                            <!-- <th>Created Date </th> -->
                                                            <!-- <th>Receivable</th> -->
                                                           <!--  <th class="hidden-sm-down">Description</th> -->
                                                            <!-- <th>Credit</th> -->
                                                            <!-- <th class="hidden-sm-down">Unit Cost</th>
                                                            <th>Total</th> -->
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                  

                              <?php
                              $count=1;

                              
                        
                  
                        
                        // print_r("SELECT  customer_id,username,email,created_date FROM tbl_customer $where_ledger  created_date BETWEEN '$f_date' AND '$t_date'");
                       // / $t = mysqli_num_rows($vendsql); 
           
                         $sql2 = "SELECT  * FROM tbl_trans_detail $where_ledger order by invoice_no desc ";
                        $vendsql2=mysqli_query($conn, $sql2);
                       
                        
                        while($ndata=mysqli_fetch_assoc($vendsql2)) {

             
                        $narration=$ndata['narration']; 
                        $invoice_no=$ndata['invoice_no'];
                        $acode=$ndata['acode'];
                        $vendor_id=substr($vendor_id, 0, 6);

                        if($vendor_id=='100200')
                        {
                            $c_amount=$ndata['d_amount'];    
                            $d_amount=$ndata['c_amount']; 
                        }
                        else
                        {
                            $c_amount=$ndata['c_amount'];    
                            $d_amount=$ndata['d_amount'];
                        }
                        $sql="SELECT aname FROM tbl_account_lv2 where acode='$acode'";
                        $result1 = mysqli_query($conn,$sql);
                        $data = mysqli_fetch_array($result1);
                          
                        $aname = $data['aname'];
                        if($aname=='')
                        {
                          $sql="SELECT aname FROM tbl_account where acode='$acode'";
                          $result1 = mysqli_query($conn,$sql);
                          $data = mysqli_fetch_array($result1);
                            
                          $aname = $data['aname'];
                        } 
                        
                        ?>
                        <tr>
                        <td><?php  echo $count;$count++; ?></td> 

                        <td><?php  echo $aname; ?></td>                         
                             <!-- <td> <a href="customer_single.php?u_id=<?php echo $vendor_id ?>&fdate=<?php echo $f_date ?>&tdate=<?php echo $t_date ?>" target="_blank"><?php echo $vendor_id;?> </a></td> -->
                        <td><?php  echo $invoice_no; ?></td> 
                         <td  width="50%; !important"><?php echo $narration;?></td>
                         <td><?php echo $d_amount; $tot_damt+=$d_amount;?></td>
                         <td><?php echo $c_amount; $tot_camt+=$c_amount;?></td>
                            <!-- <td><?php echo $total;?></td> -->
                        
                                                        </tr>
                                                       
                                                      <?php } ?>
                         <tr>
                          <td><h5>Total</h5></td>  
                           <td></td> 
                           <td></td>                             
                         <td  width="50%;"></td>
                         <td><h5><?php echo $tot_damt;?></h5></td>
                         <td><h5><?php echo $tot_camt;?></h5></td>
                            <!-- <td><?php echo $total;?></td> -->
                        
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <?php if($vendor_id=='100100'){
                       
                  $sql3=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as cash_in_hand FROM `tbl_trans_detail` WHERE LEFT(acode, 9) in('300100100', '300100300', '100100000') and created_by='1'");

                  $data3=mysqli_fetch_assoc($sql3);
                  $cash_in_hand = $data3['cash_in_hand'];

                  $sql4=mysqli_query($conn, "SELECT  opening_bal FROM `tbl_account` WHERE acode='100100000'");

                  $data4=mysqli_fetch_assoc($sql4);
                  $opening_bal = $data4['opening_bal'];

                  $cash_now=$opening_bal+$cash_in_hand;
                
                
                  
                
                                      // $sql3=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as cash_in_hand FROM `tbl_trans_detail` WHERE LEFT(acode, 6) IN('100100')");

                                      // $data3=mysqli_fetch_assoc($sql3);
                                      //         $cash_in_hand = $data3['cash_in_hand'];
                                        
                                      ?>
                                    <div class="row clearfix">
                                        <div class="col-md-6">
                                   
                                        </div>
                                        <div class="col-md-6 text-right">
                            
                                                                                   
                                            <h3 class="m-b-0  m-t-10">Cash In Hand : <?php echo round($cash_now); ?></h3>
                                        </div>                                    
                                        <div class="hidden-print col-md-12 text-right">
                                            <hr>
                                            <button type="button"  class="btn btn-danger" onclick="GoBackWithRefresh();return false;">Back</button>
                                        </div>
                                    </div>  
                                    <?php }else{
                       
                  

                  $sql4=mysqli_query($conn, "SELECT  opening_bal FROM `tbl_account` WHERE Left(acode,6)='$vendor_id'");

                  $data4=mysqli_fetch_assoc($sql4);
                  $opening_bal = $data4['opening_bal'];
                  if($opening_bal=='')
                  {
                  
                    $sql4=mysqli_query($conn, "SELECT  opening_bal FROM `tbl_account_lv2` WHERE acode='$vendor_id'");

                  $data4=mysqli_fetch_assoc($sql4);
                  $opening_bal = $data4['opening_bal'];
                  }
                  $cash_now=$opening_bal+($tot_damt-$tot_camt);
                
                
                  
                
                                      // $sql3=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as cash_in_hand FROM `tbl_trans_detail` WHERE LEFT(acode, 6) IN('100100')");

                                      // $data3=mysqli_fetch_assoc($sql3);
                                      //         $cash_in_hand = $data3['cash_in_hand'];
                                        
                                      ?>
                                    <div class="row clearfix">
                                        <div class="col-md-6">
                                   
                                        </div>
                                        <div class="col-md-6 text-right">
                            
                                            <h5 class="m-b-0  m-t-14">Opening : <?php echo round($opening_bal); ?></h5>                                     
                                            <h3 class="m-b-0  m-t-10">Balance : <?php echo round($cash_now); ?></h3>
                                        </div>                                    
                                        <div class="hidden-print col-md-12 text-right">
                                            <hr>
                                            <button type="button"  class="btn btn-danger" onclick="GoBackWithRefresh();return false;">Back</button>
                                        </div>
                                    </div>  
                                    <?php }?>

                                </div>  
                        
                            </div>   
                                            
                          
                            <div class="row clearfix ">
                                <div class="col-md-6 ">
                               
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>


    
</body>
<!-- Javascript -->


<script src="assets_light/bundles/libscripts.bundle.js"></script>    
<script src="assets_light/bundles/vendorscripts.bundle.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="assets_light/bundles/mainscripts.bundle.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.0/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.print.min.js"></script>






</body>
<script type="text/javascript">
  function GoBackWithRefresh(event) {
    if ('referrer' in document) {
        // window.location = document.referrer;
        window.location = ('customer.php');
        /* OR */
        //location.replace(document.referrer);
    } else {
      window.location('customer.php');
        // window.history.back().back();
        // window.history.back();
    }
}
</script>
<style type="text/css">
  .data-table-container {
  padding: 10px;
}

.dt-buttons .btn {
  margin-right: 3px;
}

</style>
<script type="text/javascript">
$(document).ready(function() {
          $('#example').DataTable({
      dom: 'Bfrtip',
      scrollY: true,
      scrollX: false,
      "paging":   false,
      "ordering": false,
      "info":     false,
      searching: false,
      buttons: [
        {
          extend: 'pdfHtml5',
          text: 'Alkareem',
           title: 'Alkareem (All Account Ledger)',
           
          
          text:'<span class="text-white"><i class="fa fa-file-pdf-o"></i></span><span class="text"> PDF</span>',
          
          className: 'btn btn-danger',
          
                    customize: function (doc) {
                        doc.content[1].table.widths = 
                            Array(doc.content[1].table.body[0].length + 1).join('*').split('');
                            doc.styles.tableHeader = {
                           
                           alignment: 'left'
                         }
                      }  
        },
        {
          extend: 'print',
          className: 'btn btn-success',
          titleAttr: 'print',
          text:'<span class="text-white"><i class="fa fa-print"></i></span><span class="text"> Print</span><br>', 

          
          title: '<h3 class="text-center">Alkareem</h3><br><h5 class="text-center">(All Account Ledger)</h5>',

          
        },


      ]


    });
} );
</script>
</body>

<!-- Mirrored from wrraptheme.com/templates/lucid/hr/html/light/payroll-payslip.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Jun 2021 09:01:04 GMT -->
</html>
