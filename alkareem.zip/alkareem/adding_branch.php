<!doctype html>
<html lang="en">


<!-- Mirrored from wrraptheme.com/templates/lucid/hr/html/light/client-add.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Jun 2021 09:01:13 GMT -->
<?php
error_reporting(0);
include "includes/session.php";
include "includes/config.php";
include "includes/head.php";

session_start();

if(isset($_SESSION['adminid'])){


}
else{
   header('Location: login.php'); 
}
?>
<body class="theme-orange">

<!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30"><img src="https://wrraptheme.com/templates/lucid/hr/html/assets/images/logo-icon.svg" width="48" height="48" alt="Lucid"></div>
        <p>Please wait...</p>        
    </div>
</div>
<!-- Overlay For Sidebars -->

<div id="wrapper">

    <?php
include "includes/navbar.php";

include "includes/sidebar.php";
?>

    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-6 col-md-8 col-sm-12">                        
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Add Branchs</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>                            
                            <li class="breadcrumb-item">Branchs</li>
                            <li class="breadcrumb-item active">Add</li>
                        </ul>
                    </div>            
                    <?php include "includes/graph.php";?>
                </div>
            </div>

             <div class="alert alert-success" id="success-alert" style="display: none;">
  
              <strong>Great!</strong> Branch Added Succesfully.
            </div>
            <div class="alert alert-danger" id="email-alert" style="display: none;">
  
              <strong>Ooops!</strong> Email Already Exist.
            </div>
            <div class="alert alert-danger" id="error-alert" style="display: none;">
  
              <strong>Ooops!</strong> Form Submit Error.
            </div>
              
       
  
  
    
            
            <div class="row clearfix">
                <div class="col-12">
                    <div class="card">
                        <div class="body">
                            <?php
                            $edit_id=$_GET['edit_id'];
                           
                            $customer_edit = mysqli_query($conn,"SELECT * FROM tbl_vendors where v_id='$edit_id'   ");
                                $row = mysqli_fetch_assoc($customer_edit);   
                               
                                    $email=$row['email'];
                                    $username=$row['username'];
                                 
                                    $mobile_no=$row['mobile_no'];
                                    $user_profile=$row['user_profile'];
                                    $address=$row['address'];




                                    

                            ?>
                        <form action="" method="post" id="form1" enctype="multipart/form-data">
                            <div class="row clearfix">
                                  <div class="col-md-4 col-sm-12">
                                    <div class="form-group">                                   
                                        <input type="text" name="branchname" id="branchname"   class="form-control" placeholder="Branch Name *" value="">
                                        <p id='b_error' ></p>
                                    </div>
                                </div>
                                       
                                
                                 <div class="col-md-4 col-sm-12">
                                    <div class="form-group">                                   
                                        <input type="email" name="email" id="email"   class="form-control" placeholder="Email *" value="<?php echo $branchname; ?>">
                                        <p id='e_email' ></p>
                                    </div>
                                </div>
                                        
                              <!--  -->
                                 
                        
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <input type="text" name="contact_no" id="contact_no"   class="form-control" placeholder="Contact No" value="<?php echo $contact_no; ?>">
                                        <p id='e_contact_no' ></p>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <input type="text" name="mobile_no" id="mobile_no"   class="form-control" placeholder="Mobile No" value="<?php echo $mobile_no; ?>">
                                        <p id='e_mobile_no' ></p>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <input type="text" name="owner_name" id="owner_name"   class="form-control" placeholder="Owner Name" value="<?php echo $owner_name; ?>">
                                        <p id='e_owner_name' ></p>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <input type="password" name="user_password" id="user_password" class="form-control" placeholder="Password" value="<?php echo $password;?>">
                                        <p id='e_user_password' ></p>
                                    </div>
                                </div>
                                 
                                   
                                <div class="col-md-8 col-sm-12">
                                    <div class="form-group">
                                        <input type="text" name="address" id="address" class="form-control" placeholder="Address" value="<?php echo $address; ?>">
                                        <p id='e_address' ></p>
                                         <input type="hidden" name="edit_id" id="edit_id" class="form-control"  value="<?php echo $edit_id; ?>">
                                    </div>

                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <input type="password" name="confirm_password" id="confirm_password"class="form-control" placeholder="Confirm Password" value="<?php echo $confirm_password;?>">
                                        <p id='e_confirm_password' ></p>

                                    </div>
                                </div>

                                 
                                 
                                               
                            </div>
                   
                                   
                <button type="submit" name="addvendors" id="addvendors" class="btn btn-primary">Add</button>
                <button type="button"  class="btn btn-danger" onclick="GoBackWithRefresh();return false;">Back</button>

                        </div>
                        </form> 

                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>


<!-- Javascript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="assets_light/bundles/libscripts.bundle.js"></script>    
<script src="assets_light/bundles/vendorscripts.bundle.js"></script>

<script src="assets_light/bundles/easypiechart.bundle.js"></script> <!-- easypiechart Plugin Js -->

<script src="assets_light/bundles/mainscripts.bundle.js"></script>
  <script>      
    $(document).ready(function() {
        $("form").submit(function(event){
            var br=$('#branchname').val();
            var em=$('#email').val();
            var mob_no=$('#mobile_no').val();
            var usr_psw=$('#user_password').val();
            var c_psw=$('#confirm_password').val();
            if(br==''){
                // alert('error');
            $('#b_error').text("Name Required*");
            $('#b_error').css('color','red');
            // return false; 
           }
           if(em==''){
            $('#e_email').text("Email Required*");
            $('#e_email').css('color','red'); 
           }if(mob_no==''){
            $('#e_mobile_no').text("Mobile Number Required*");
            $('#e_mobile_no').css('color','red'); 
           }if(usr_psw==''){
            $('#e_user_password').text("Password Required*");
            $('#e_user_password').css('color','red'); 
           }if(c_psw==''){
            $('#e_confirm_password').text("Confirm Password Required*");
            $('#e_confirm_password').css('color','red'); 
           }else{
            var formData = {
                name:$("#branchname").val(),
                email:$("#email").val(),
                contact_no:$("#contact_no").val(),
                mobile_no:$("#mobile_no").val(),
                owner_name:$("#owner_name").val(),
                user_password:$("#user_password").val(),
                confirm_password:$("#confirm_password").val(),
                address:$("#address").val(),
                // edit_id:$("#edit_id").val(),

            };
           
            // console.log(formData);
            $.ajax({
                type: "POST",
                url:"operations/branch_add.php",
                data: formData,
                dataType: "json",    
                encode: true,

            }).done(function(data){
      
                if(data=="data inserted"){
                  $("#success-alert").hide();

                    $("#success-alert").fadeTo(4000, 500).slideUp(500, function() {
                      $("#success-alert").slideUp(500);
                    });
                    $("#branchname").val('');
                    $("#email").val('');
                    $("#contact_no").val('');
                    $("#mobile_no").val('');
                    $("#owner_name").val('');
                    $("#user_password").val('');
                    $("#confirm_password").val('');
                    $("#address").val('');
                }
                if(data=="Email Exist") {
                    // console.log("Field");
                    $("#email").focus();
                    $("#email-alert").hide();

                    $("#email-alert").fadeTo(4000, 500).slideUp(500, function() {
                      $("#email-alert").slideUp(500);
                    });
                }
                if(data=="error-alert") {
                    // console.log("Field");
                    // $("#email").focus();
                    $("#email-alert").hide();

                    $("#email-alert").fadeTo(4000, 500).slideUp(500, function() {
                      $("#email-alert").slideUp(500);
                    });
                }
                    
                   
                   
                    });}
                        event.preventDefault(); 
                    });
                    
                });

function GoBackWithRefresh(event) {
    if ('referrer' in document) {
        window.location = document.referrer;
        /* OR */
        //location.replace(document.referrer);
    } else {
        window.history.back();
    }
}
</script> 
</body>

<!-- Mirrored from wrraptheme.com/templates/lucid/hr/html/light/client-add.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Jun 2021 09:01:13 GMT -->
</html>
