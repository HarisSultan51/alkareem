<?php 
error_reporting(0);
include "includes/session.php";
include "includes/config.php";
session_start();
if(isset($_SESSION['adminid'])){


}
else{
   header('Location: login.php'); 
}?>
 <?php 
$vendor_id = $_POST['vendors'];
$f_date = $_POST['f_date'];
$t_date = $_POST['t_date'];





   ?>
<html lang="en" >
<link rel="icon" href="favicon.ico" type="image/x-icon"><!-- VENDOR CSS -->
<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">

<!-- MAIN CSS -->
<link rel="stylesheet" href="assets_light/css/main.css">
<link rel="stylesheet" href="assets_light/css/color_skins.css">

<body >

            <div class="row clearfix" >
                <div class="col-lg-12 col-md-12">
                    <div class="card invoice1">                        
                        <div class="body">
                       
                          <?php 
                        
                         error_reporting(0);
                        $sql=mysqli_query($conn, "SELECT * FROM tbl_company ");
                        $data=mysqli_fetch_assoc($sql);
                        $c_name = $data['c_name'];
                        $c_address = $data['c_address'];
                        $c_phone = $data['c_phone'];
                        $c_mobile = $data['c_mobile'];
                        $image = $data['user_profile'];
                        
                      
                        ?>
                        <div class="row">
                            <div class="invoice-top clearfix col-md-12">

                                <div class="logo" style='width: 7%;'>
                                    <img src="<?php echo $image; ?>"  alt="user" class="img-fluid">
                                </div>
                                <div class="info text-center col-md-12" style="margin-top: 1%;" >
                                    <h1><?php echo $c_name;?></h1>
                                    <h3>VENDOR WISE REPORT</h3>

                                  
                                </div>

                            </div>
                              </div>
                                      <div class="row">
                            <div class="clearfix col-md-12" >
                                <div class="info text-center col-md-12"  >
                                   <p>(<?php echo $c_address;?>)<br><?php echo $c_phone;?></p>
                               </div> </div>
                              </div>
                              <!-- <div class="row">
                            <div class="clearfix col-md-12" >
                                <div class="info text-center col-md-12"  >
                                   <p>VENDOR WISE REPORT</p>
                               </div> </div>
                              </div> -->
                            
                       

                               
                            <hr> <br> <h4><?php echo $user_name; $count=1;?></h4>
                                              <div class="row clearfix">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-hover">
                                                    <thead class="thead-dark">
                                                        <tr>
                                                                                         
                                                                                                 
                                                                       
                                                            <!-- <th >ID</th> -->
                                                            <th >Name</th>
                                                            <th >Email</th>
                                                            <th >Payout Status</th>
                                         
                                                            <th >Created Date </th>
                                                            <th>Payable</th>
                                      
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                <?php 

                                if($vendor_id=='All'){
                            $user_name='All';
                        }
                        if($vendor_id!='All'){
                            
                        $nsql=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as total FROM `tbl_trans_detail` where acode='$vendor_id'");
                        $narsql=mysqli_query($conn, "SELECT narration FROM tbl_trans where vendor_id ='$vendor_id' LIMIT 1");
                        $datesql=mysqli_query($conn, "SELECT created_date FROM tbl_account_lv2 where created_date between '$f_date' and '$t_date' and  acode ='$vendor_id'");

                    
                                    $vendsql=mysqli_query($conn, "SELECT username,email FROM tbl_vendors where   vendor_id ='$vendor_id'");
                                  
                                
                        

                        $ndata=mysqli_fetch_assoc($vendsql); 
                        $ven_name = $ndata['username'];
                        $email = $ndata['email'];
                        $date=mysqli_fetch_assoc($datesql); 
                        $nardata=mysqli_fetch_assoc($narsql); 
                        $beforetotal=mysqli_fetch_assoc($nsql); 
                        $total=$beforetotal['total']; 
                        if($total==''){
                            $total=0;
                        }
                        $created_date=$date['created_date']; 
                        // print_r($vendor_id);
                        if ($total ==0){
                          $status = 'Clear'; 
                        }else{
                          $status = 'Pending';
                        }
                        
                        }

                                if($vendor_id!='All' && $created_date!=''){ ?>
                                                         <tr>
                            <!-- <td style="width:20px;"><a href="single.php?u_id=<?php echo $vendor_id ?>&fdate=<?php echo $f_date ?>&tdate=<?php echo $t_date ?>" target="_blank"><?php $count1=1;
                            echo $count1;$count1++;?></a></td> -->
                           
                         <?php 

                          if ($total==0 ){ ?>
                            <td><?php echo $ven_name;?></td>
                            <td><?php echo $email;?></td>
                            <td><?php echo $status;?></td>
                            <td><?php echo $created_date;?></td>
                            <td><?php echo (abs($total));?></td>
                            <!-- <td><?php echo $total;?></td> -->
                         <?php }else{ ?>
                          <td><?php echo $ven_name;?></td>
                          <td><?php echo $email;?></td>
                          <td><?php echo $status;?></td>
                          <td><?php echo $created_date;?></td>
                          <td><?php echo (abs($total));?></td>
                            <!-- <td><?php echo $credit;?></td> -->
                              <?php } ?>
                                                        </tr><?php } ?>
                                                  
                                <?php 
                                if($vendor_id=='All'){ 
                                $count1 = 1;
                        $vendsql=mysqli_query($conn, "SELECT * FROM tbl_vendors  ");
                        $tdata=mysqli_num_rows($vendsql);

                        while($tdata){
          
                        $ndata=mysqli_fetch_assoc($vendsql);
                        $vendor_id= $ndata['vendor_id'];
                            // print_r($vendor_id);
                        $nsql=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as total FROM `tbl_trans_detail` where acode='$vendor_id'");
                        $narsql=mysqli_query($conn, "SELECT narration FROM tbl_trans where vendor_id ='$vendor_id' LIMIT 1");
                        $datesql=mysqli_query($conn, "SELECT created_date FROM tbl_account_lv2 where acode =$vendor_id AND created_date   between '$f_date' and '$t_date' ");
                        $date=mysqli_fetch_assoc($datesql); 
                        // $daten = mysqli_num_rows($datesql);
                        $nardata=mysqli_fetch_assoc($narsql); 
                        $beforetotal=mysqli_fetch_assoc($nsql); 
                        $total=$beforetotal['total']; 
                        if($total==''){
                            $total=0;
                        }
                        $created_date=$date['created_date']; 
                        // print_r($vendor_id);
                        if ($total ==0){
                          $status = 'Clear'; 
                        }else{
                          $status = 'Pending';
                        }
                        $username = $ndata['username'];
                        $email = $ndata['email'];
                        // }
                        if($created_date!=''){
                        ?>

                                                        <tr>
                            <!-- <td style="width:20px;"><a href="single.php?u_id=<?php echo $vendor_id ?>&fdate=<?php echo $f_date ?>&tdate=<?php echo $t_date ?>" target="_blank"><?php 
                            echo $count1;$count1++;?></a></td> -->
                           
                         <?php

                          if ($total==0 ){ ?>
                            <td><?php echo $username;?></td>
                            <td><?php echo $email;?></td>
                            <td><?php echo $status;?></td>
                            <td><?php echo $created_date;?></td>
                            <td><?php echo (abs($total));?></td>
                            <!-- <td><?php echo $total;?></td> -->
                         <?php }else 
                             { ?>
                          <td><?php echo $username;?></td>
                          <td><?php echo $email;?></td>
                          <td><?php echo $status;?></td>
                          <td><?php echo $created_date;?></td>
                          <td><?php echo (abs($total));?></td>
                            <!-- <td><?php echo $credit;?></td> -->
                              <?php } ?>
                                                        </tr>
                                                    <?php }} }?>   
                                                      
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row clearfix">
                                        <div class="col-md-6">
                                   
                                        </div>
                                        <div class="col-md-6 text-right">
                                            <p class="m-b-0"><b>Sub-total:</b> <?php echo $total_amount; ?></p>
                                            <p class="m-b-0">Discout: <?php echo $discount; ?>%</p>
                                                                                   
                                            <h3 class="m-b-0 m-t-10">NET AMT - <?php $net_amount=$total_amount-$discount; echo $net_amount; ?></h3>
                                        </div>                                    
                                        <div class="hidden-print col-md-12 text-right">
                                            <hr>
                                            
                                        </div>
                                    </div>                                    
                                </div>  
                        
                            </div>   
                                            
                          
                            <div class="row clearfix ">
                                <div class="col-md-6 ">
                               
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>


    
</body>

<script src="assets_light/bundles/libscripts.bundle.js"></script>    
<script src="assets_light/bundles/vendorscripts.bundle.js"></script>

<script src="assets_light/bundles/mainscripts.bundle.js"></script>
</body>

</html>
