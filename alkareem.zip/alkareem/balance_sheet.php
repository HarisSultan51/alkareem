<?php 
error_reporting(0);
include "includes/session.php";
include "includes/config.php";
session_start();
if(isset($_SESSION['adminid'])){


}
else{
   header('Location: login.php'); 
}?>
 <?php 

  $f_date=mysqli_real_escape_string($conn,$_POST['f_date']);
  $t_date=mysqli_real_escape_string($conn,$_POST['t_date']);
   ?>
<html lang="en" >
<link rel="icon" href="favicon.ico" type="image/x-icon"><!-- VENDOR CSS -->
<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">

<!-- MAIN CSS -->
<link rel="stylesheet" href="assets_light/css/main.css">
<link rel="stylesheet" href="assets_light/css/color_skins.css">
<link rel="icon" href="favicon.ico" type="image/x-icon"><!-- VENDOR CSS -->
<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<style type="text/css">
    td  .m-b-0 .m-t-6{
        color: red;
    }
</style>
<body >

            <div class="row clearfix" >
                <div class="col-lg-12 col-md-12">
                    <div class="card invoice1">                        
                        <div class="body">
                        <?php 
                        error_reporting(0);
                        $sql=mysqli_query($conn, "SELECT * FROM tbl_company ");
                        $data=mysqli_fetch_assoc($sql);
                        $c_name = $data['c_name'];
                        $c_address = $data['c_address'];
                        $c_phone = $data['c_phone'];
                        $c_mobile = $data['c_mobile'];
                        $image = $data['user_profile'];
                 
                        ?>
                        <div class="row">
                            <div class="invoice-top clearfix col-md-12">

                                <div class="logo" style='width: 7%;'>
                                    <img src="<?php echo $image; ?>"  alt="user" class="img-fluid">
                                </div>
                                <div class="info text-right col-md-6" style="margin-top: 1%;" >
                                    <h1><?php echo $c_name;?></h1>
                                    <h3>Balance Sheet</h3>

                                  
                                </div>

                            </div>
                              </div>
                                      <div class="row">
                            <div class="clearfix col-md-12" >
                                <div class="info text-center col-md-12"  >
                                   <p>(<?php echo $c_address;?>)<br><?php echo $c_phone;?></p>
                               </div> </div>
                              </div>


                               <div class="row">
                                   
                            <div class="clearfix text-right col-md-12" >

                            <span > <b>FROM DATE/TO DATE : </b> <?php echo $f_date.'/'.$t_date;?>
                       </span></div> </div> 
                            <hr>  

<?php
///////////////////////// cash at bank///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account_lv2 where Left(acode, 6)='100700' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_bank = $data['opening_bal'];

$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as bank_bal FROM tbl_trans_detail where Left(acode, 6)='100700' and created_date between '$f_date' and '$t_date' and created_by='$userid'");
$data1=mysqli_fetch_assoc($sql1);
$bank_bal = $data1['bank_bal'];

$bank_total=$opening_bal_bank+$bank_bal;
///////////////////////////////////////////////////////////////////////////

///////////////////////// Accounts Rec ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account_lv2 where Left(acode, 6)='100200' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_acc_rec = $data['opening_bal'];

$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as acc_rec_bal FROM tbl_trans_detail where Left(acode, 6)='100200' and created_date between '$f_date' and '$t_date'");
$data1=mysqli_fetch_assoc($sql1);
$acc_rec_bal = $data1['acc_rec_bal'];

$acc_rec_total=$opening_bal_acc_rec+$acc_rec_bal;
///////////////////////////////////////////////////////////////////////////


///////////////////////// Cash in hand ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account_lv2 where Left(acode, 6)='300100' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_cogs = $data['opening_bal'];

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account_lv2 where Left(acode, 6)='100100' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_branch = $data['opening_bal'];

$query=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account where Left(acode, 6)='100100' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data2=mysqli_fetch_assoc($query);
$opening_bal_cih = $data2['opening_bal'];

$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as cash_in_hand FROM tbl_trans_detail where Left(acode, 6) IN('100100',  '300100', '300200') and created_date between '$f_date' and '$t_date'");
$data1=mysqli_fetch_assoc($sql1);
$cash_in_hand = $data1['cash_in_hand'];

$cash_in_hand_total=$opening_bal_cih+$cash_in_hand+$opening_bal_cogs+$opening_bal_branch;
///////////////////////////////////////////////////////////////////////////


///////////////////////// Inventory in hand ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account where Left(acode, 6)='100300' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_stock = $data['opening_bal'];


$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as stock_in_hand FROM tbl_trans_detail where Left(acode, 6)IN('100300',  '100000') and created_date between '$f_date' and '$t_date'");
$data1=mysqli_fetch_assoc($sql1);
$stock_in_hand = $data1['stock_in_hand'];

$stock_in_hand_total=$opening_bal_stock+$stock_in_hand;
$current_assests=$stock_in_hand_total+$cash_in_hand_total+$acc_rec_total+$bank_total;
///////////////////////////////////////////////////////////////////////////

///////////////////////// Buildings ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account where Left(acode, 6)='100600' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_land = $data['opening_bal'];


$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as land FROM tbl_trans_detail where Left(acode, 6)='100600' and created_date between '$f_date' and '$t_date' and created_by='$userid'");
$data1=mysqli_fetch_assoc($sql1);
$land = $data1['land'];

$land_total=$opening_bal_land+$land;

///////////////////////////////////////////////////////////////////////////

///////////////////////// Equipement ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account where Left(acode, 6)='100800' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_equip = $data['opening_bal'];


$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as equip FROM tbl_trans_detail where Left(acode, 6)='100800' and created_date between '$f_date' and '$t_date' and created_by='$userid'");
$data1=mysqli_fetch_assoc($sql1);
$equip = $data1['equip'];

$equip_total=$opening_bal_equip+$equip;
$non_current_assests=$equip_total+$land_total;
///////////////////////////////////////////////////////////////////////////
////////////////////////////////Assests total //////////////////////////
$assests=$non_current_assests+$current_assests;
///////////////////////////////////////////////////////////////////////


///////////////////////// Account payable ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account_lv2 where Left(acode, 6)='200200' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_payable = $data['opening_bal'];


$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as payable FROM tbl_trans_detail where Left(acode, 6)='200200' and created_date between '$f_date' and '$t_date'");
$data1=mysqli_fetch_assoc($sql1);
$payable = $data1['payable'];

$payable_total=(-$opening_bal_payable+$payable);

///////////////////////////////////////////////////////////////////////////

///////////////////////// Accrued Expense ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account_lv2 where Left(acode, 6)='500200' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_expense = $data['opening_bal'];


$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as expense FROM tbl_trans_detail where Left(acode, 6)='500200' and created_date between '$f_date' and '$t_date'");
$data1=mysqli_fetch_assoc($sql1);
$expense = $data1['expense'];

$expense_total=($opening_bal_expense+$expense);

///////////////////////////////////////////////////////////////////////////

///////////////////////// Salary/Wages ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account_lv2 where Left(acode, 6)='500100' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_salary = $data['opening_bal'];


$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as salary FROM tbl_trans_detail where Left(acode, 6)='500100' and created_date between '$f_date' and '$t_date'");
$data1=mysqli_fetch_assoc($sql1);
$salary = $data1['salary'];

$salary_total=($opening_bal_salary+$salary);

///////////////////////////////////////////////////////////////////////////
////////////////////////////////Liabilities total //////////////////////////
$liabilities=$salary_total+$expense_total+$payable_total;
///////////////////////////////////////////////////////////////////////


///////////////////////// Owner Contribution ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account_lv2 where Left(acode, 6)='400100' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_owner = $data['opening_bal'];


$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as contribution FROM tbl_trans_detail where Left(acode, 6)='400100' and created_date between '$f_date' and '$t_date' and created_by='$userid'");
$data1=mysqli_fetch_assoc($sql1);
$contribution = $data1['contribution'];

$owner_total=($opening_bal_owner+$contribution);

///////////////////////////////////////////////////////////////////////////

///////////////////////// Owner Draws ///////////////////////////////////////

$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account_lv2 where Left(acode, 6)='400200' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_draws = $data['opening_bal'];


$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as draws FROM tbl_trans_detail where Left(acode, 6)='400200' and created_date between '$f_date' and '$t_date' and created_by='$userid'");
$data1=mysqli_fetch_assoc($sql1);
$draws = $data1['draws'];

$owner_draws_total=($opening_bal_draws+$draws);

///////////////////////////////////////////////////////////////////////////
////////////////////////////////total Earning//////////////////////////
$earning=$assests-$liabilities;
///////////////////////////////////////////////////////////////////////
?>














                                              <div class="row clearfix">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table id="example" class="display" style="width:100%">
                                                    <thead class="thead-dark">
                                                        <tr>  
                                                                   
                                                            <th>Account</th>
                                                            <th>Amount</th>   
                                                            
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td><h5 class="m-b-0 m-t-10">Currrent Assets</h5></td>
                                                            <td><h7 class="m-b-0 m-t-6"></h7></td>
                                                        </tr>
                                                        <tr>

                                                            <td><h6 class="m-b-0 m-t-10">Cash at bank</h6></td>
                                                            <td><h7 class="m-b-0 m-t-6 text-right"><?php echo $bank_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Accounts Receivable</h6></td>
                                                            <td><h7 class="m-b-0 m-t-6 text-right"><?php echo $acc_rec_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Cash in hand</h6></td>
                                                            <td><h7 class="m-b-0 m-t-6 text-right"><?php echo $cash_in_hand_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Inventory On Hand</h6></td>
                                                            <td><h7 class="m-b-0 m-t-6 text-right"><?php echo $stock_in_hand_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Security Deposits </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6 text-right">0.00</h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Stores and Spares</h6></td>
                                                            <td><h7 class="m-b-0 m-t-6 text-right">0.00</h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10"><b>Total Current Assets </b></h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $current_assests;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h5 class="m-b-0 m-t-10">Non Currrent Assets</h5></td>
                                                            <td><h7 class="m-b-0 m-t-6"></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Building and Land</h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $land_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Equipments</h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $equip_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10"><b>Total Assets Non Current Assets</b></h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $non_current_assests;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10"><b>Total Assets </b></h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $assests;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h5 class="m-b-0 m-t-10">Liabilities</h5></td>
                                                            <td><h7 class="m-b-0 m-t-6"></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10"><b>Current Liabilities </b></h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Account payable </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $payable_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Accrued Expense </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $expense_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Custom duty, cess and others </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6">0.00</h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10">Employee's Salaries </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $salary_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10"><b>Total Current Liabilities</b> </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $liabilities;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h5 class="m-b-0 m-t-10">Equity</h5></td>
                                                            <td><h7 class="m-b-0 m-t-6"></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10"><b>Owner's Capital</b> </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $owner_total;?></h7></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10"><b>Owner's Draw</b> </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $owner_draws_total;?></h7></td>
                                                        </tr>
                                                        <?php

                                                            $bsql=mysqli_query($conn,"SELECT * FROM `tbl_account` where LEFT(acode,6) between '40020000' and '500000000' and created_date between '$f_date' and '$t_date' ");
                                                            while($value = mysqli_fetch_assoc($bsql))   
                                                        {
                                                            $aname=$value['aname'];
                                                            $acode=$value['acode'];


$sql=mysqli_query($conn, "SELECT SUM(opening_bal) as opening_bal FROM tbl_account where acode='$acode' and opening_date between '$f_date' and '$t_date' and created_by='$userid'");
$data=mysqli_fetch_assoc($sql);
$opening_bal_shareholder = $data['opening_bal'];


$sql1=mysqli_query($conn, "SELECT SUM(d_amount-c_amount) as shareholder FROM tbl_trans_detail where acode='$acode' and created_date between '$f_date' and '$t_date' and created_by='$userid'");
$data1=mysqli_fetch_assoc($sql1);
$shareholder = $data1['shareholder'];

$shareholder_total=($opening_bal_shareholder+$shareholder);
                                                            ?>
                                                         <tr>
                                                            <td><h6 class="m-b-0 m-t-10"><b><?php echo $aname;?></b> </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $shareholder_total;?></h7></td>
                                                        </tr>
                                                        <?php }
                                                        ?>
                                                        <tr>
                                                            <td><h6 class="m-b-0 m-t-10"><b>Total Earning</b> </h6></td>
                                                            <td><h7 class="m-b-0 m-t-6"><?php echo $earning;?></h7></td>
                                                        </tr>
                                                         <tr>
                                                            <td><h4 class="m-b-0 m-t-10"><b>Total Equity</b> </h4></td>
                                                            <td><h4 class="m-b-0 m-t-6"><?php echo $assests;?></h4></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                   <!--  <div class="row clearfix">
                                        <div class="col-md-6">
                                   
                                        </div>
                                        <div class="col-md-6 text-right">
                                  
                                                                                   
                                            <h3 class="m-b-0 m-t-10">AMT ( <?php $net_amount=$total_damount-$total_camount; echo $net_amount; ?> )</h3>
                                        </div>                                    
                                        <div class="hidden-print col-md-12 text-right">
                                            <hr>
                                            
                                        </div>
                                    </div>  -->                                   
                                </div>  
                        
                            </div>   
                                            
                          
                            <div class="row clearfix ">
                                <div class="col-md-6 ">
                               
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>


    
</body>
<script src="assets_light/bundles/libscripts.bundle.js"></script>    
<script src="assets_light/bundles/vendorscripts.bundle.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="assets_light/bundles/mainscripts.bundle.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.0/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.print.min.js"></script>






</body>
<style type="text/css">
  .data-table-container {
  padding: 10px;
}

.dt-buttons .btn {
  margin-right: 3px;
}

</style>
<script type="text/javascript">
$(document).ready(function() {
          $('#example').DataTable({
      dom: 'Bfrtip',
      scrollY: true,
      scrollX: false,
      "paging":   false,
      "ordering": false,
      "info":     false,
      searching: false,
      buttons: [
             {
          extend: 'pdfHtml5',
          text: 'Alkareem',
           
           title: 'Alkareem (Balance Sheet)',
           
          
          text:'<span class="text-white"><i class="fa fa-file-pdf-o"></i></span><span class="text"> PDF</span>',
          
          className: 'btn btn-danger',
          
                     customize: function (doc) {
                        doc.content[1].table.widths = 
                            Array(doc.content[1].table.body[0].length + 1).join('*').split('');
                            doc.styles.tableHeader = {
                           
                           alignment: 'left'
                         }
                      }
        
        },
        {
          extend: 'print',
          className: 'btn btn-success',
          titleAttr: 'print',
          text:'<span class="text-white"><i class="fa fa-print"></i></span><span class="text"> Print</span><br>', 

          
          title: 'Alkareem (Balance Sheet)',

          
        },


      ]


    });
} );
</script>


<!-- Mirrored from wrraptheme.com/templates/lucid/hr/html/light/payroll-payslip.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Jun 2021 09:01:04 GMT -->
</html>
