<!doctype html>
<html lang="en">



<?php include "includes/head.php";
?>


<body class="theme-orange"  style="background-color: orange;">
	<!-- WRAPPER -->
	<div id="wrapper">
		<div class="vertical-align-wrap">
			<div class="vertical-align-middle auth-main" >
				<div class="auth-box">
                    <div class="top">
                       <img src="https://wrraptheme.com/templates/lucid/hr/html/assets/images/logo-icon.svg" class="img-responsive logo" alt="Alkareem"  style="width: 70px;"><span style="color: white; font-size: 20px;">lkareem</span>
                    </div>
					<div class="card">
                            <?php
                             error_reporting(0);
                            if(isset($_GET['log']) && $_GET['log']=='incorrect' || $_GET['log']=='notfound'){
               
                                    ?>
                                    <div class="alert alert-danger" id="danger-alert">
  
  <strong>Opps!</strong> One or more details are incorrect. Please try again.
</div>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#danger-alert").hide();

    $("#danger-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#danger-alert").slideUp(500);
    });
  });
    </script>
                        
                            <?php
                            }
                                    if(isset($_GET['log']) && $_GET['log']=='denied'){
               
                                    ?>
                                    <div class="alert alert-danger" id="danger-alert">
  
  <strong>Opps!</strong> Only Admin can Login.
</div>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#danger-alert").hide();

    $("#danger-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#danger-alert").slideUp(500);
    });
  });
    </script>
                        
                            <?php
                            }

                            ?>
                <?php
              
              if(isset($_GET['log']) && $_GET['log']=='reseted' ){
                  ?>
                  <div class="alert alert-success" id="success-alert">
  
  <strong>Great!</strong> Password Reset Succesfully. Please Login again.
</div>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#success-alert").hide();

    $("#success-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#success-alert").slideUp(500);
    });
  });
    </script>
            
              <?php
              }

              if(isset($_GET['registration']) && $_GET['registration']=='successful' ){
                  ?>
                  <div class="alert alert-success" id="success-alert">
  
  <strong>Great!</strong> Registered Succesfully. Please Login.
</div>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#success-alert").hide();

    $("#success-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#success-alert").slideUp(500);
    });
  });
    </script>
            
              <?php
              }
              ?>
                        <div class="header">
                            <p class="lead">Login to your account</p>
                        </div>
                        <div class="body">
                            <form class="form-auth-small" action="operations/signin.php" method="post">
                                <div class="form-group">
                                    <label for="signin-email" class="control-label sr-only">Email</label>
                                    <input type="email" name='email' class="form-control" id="signin-email"  placeholder="Email" required="">
                                </div>
                                <div class="form-group">
                                    <label for="signin-password" class="control-label sr-only">Password</label>
                                    <input type="password" name='password' class="form-control" id="signin-password"  placeholder="Password" required="">
                                </div>
                                <div class="form-group clearfix">
                                    <label class="fancy-checkbox element-left">
                                        <input type="checkbox">
                                        <span>Remember me</span>
                                    </label>								
                                </div>
                                <button type="submit" class="btn btn-primary btn-lg btn-block" name="login">LOGIN</button>
                                <div class="bottom">
                                    <span class="helper-text m-b-10"><i class="fa fa-lock"></i> <a href="#">Forgot password?</a></span>
                                    <span>Don't have an account? <a href="register.php">Register</a></span>
                                </div>
                            </form>
                        </div>
                    </div>
				</div>
			</div>
		</div>
	</div>
	<!-- END WRAPPER -->
</body>

<!-- Mirrored from wrraptheme.com/templates/lucid/hr/html/light/page-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Jun 2021 09:00:55 GMT -->
</html>
