    
    <nav class="navbar navbar-fixed-top" style="background-color: orange; color: white">
        <div class="container-fluid">
            <div class="navbar-btn">
                <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
            </div>

            <div class="navbar-brand">
                <a href="#"><img src="https://wrraptheme.com/templates/lucid/hr/html/assets/images/logo-icon.svg" class="img-responsive logo" alt="Alkareem"  style="width: 20px;"><span style="color: white">lkareem</span></a>                
            </div>
            
            <div class="navbar-right">
                <form id="navbar-search" class="navbar-form search-form" hidden="">
                    <input value="" class="form-control" placeholder="Search here..." type="text">
                    <button type="button" class="btn btn-default"><i class="icon-magnifier"></i></button>
                </form>               

                <div id="navbar-menu">
                    <ul class="nav navbar-nav">                        
                        <li hidden=""><a href="app-events.html" class="icon-menu d-none d-sm-block d-md-none d-lg-block"><i class="icon-calendar"></i></a></li>
                        <li hidden=""><a href="app-chat.html" class="icon-menu d-none d-sm-block"><i class="icon-bubbles"></i></a></li>
                        <li hidden=""><a href="app-inbox.html" class="icon-menu d-none d-sm-block"><i class="icon-envelope"></i><span class="notification-dot"></span></a></li>
                        
                        <li class="dropdown" hidden="">
                            <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown">
                                <i class="icon-bell"></i>
                                <span class="notification-dot"></span>
                            </a>
                            <ul class="dropdown-menu notifications animated shake">
                                <li class="header"><strong>You have 4 new Notifications</strong></li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <div class="media">
                                            <div class="media-left">
                                                <i class="icon-info text-warning"></i>
                                            </div>
                                            <div class="media-body">
                                                <p class="text">Campaign <strong>Holiday Sale</strong> is nearly reach budget limit.</p>
                                                <span class="timestamp">10:00 AM Today</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>                               
                                <li>
                                    <a href="javascript:void(0);">
                                        <div class="media">
                                            <div class="media-left">
                                                <i class="icon-like text-success"></i>
                                            </div>
                                            <div class="media-body">
                                                <p class="text">Your New Campaign <strong>Holiday Sale</strong> is approved.</p>
                                                <span class="timestamp">11:30 AM Today</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                 
                                <li class="footer"><a href="javascript:void(0);" class="more">See all notifications</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown"><i class="icon-equalizer"></i></a>
                            <ul class="dropdown-menu user-menu menu-icon animated bounceIn">
                                <li class="menu-heading">GENERAL LINKS</li>
                                <li><a href="./profile.php"><i class="icon-note"></i> <span>Profile</span></a></li>
                                <li><a href="./add_sale.php"><i class="icon-credit-card"></i> <span>Cash Sale</span></a></li>
                                <li><a href="./Installment_customer.php"><i class=" icon-share-alt"></i> <span> Add Installment</span></a></li>
                                <li><a href="./installment_payment.php"><i class="icon-credit-card"></i> <span>Installment Payment</span></a></li>
                                <li class="menu-heading">REPORTS</li>
                                <li><a href="./trail_balance.php"><i class="icon-equalizer"></i> <span>Trial Balance</span></a></li>
                                <li><a href="./inventory.php"><i class="icon-docs"></i> <span>Inventory Report</span></a></li>                                
                                <li><a href="./add_payment.php"><i class="icon-rocket"></i> <span>Payments</span></a></li>
                            </ul>
                        </li>
                        <li><a href="logout.php" class="icon-menu"><i class="icon-login"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    