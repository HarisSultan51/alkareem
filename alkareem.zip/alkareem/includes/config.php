<?php
// $servername = "localhost";
// $username = "u153436862_alkareemuser";
// $password = "|vx2vEFJDz6";
// $dbname = "u153436862_alkareem";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alkareem";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
?>