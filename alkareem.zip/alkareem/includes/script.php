<script src="../assets/bundles/libscripts.bundle.js"></script>
<script src="../assets/bundles/vendorscripts.bundle.js"></script>

<script src="assets_light/vendor/toastr/toastr.js"></script>
<script src="../assets/bundles/chartist.bundle.js"></script>
<script src="../assets/bundles/knob.bundle.js"></script> <!-- Jquery Knob-->

<script src="../assets/bundles/mainscripts.bundle.js"></script>
<script src="../assets/js/index.js"></script>