<?php
session_start();
if(!isset($_SESSION['adminid'])){
header("Location: login.php?access=denied");	
}
else{
	$userid=$_SESSION['adminid'];
}
?>