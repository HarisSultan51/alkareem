-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2021 at 03:10 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alkareem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_account`
--

CREATE TABLE `tbl_account` (
  `id` int(11) NOT NULL,
  `parent_code` int(11) DEFAULT NULL,
  `acode` int(11) DEFAULT NULL,
  `aname` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_account`
--

INSERT INTO `tbl_account` (`id`, `parent_code`, `acode`, `aname`, `created_date`, `created_by`) VALUES
(2, 100000000, 100100000, 'Cash in Hand', '2021-07-14', 1),
(3, 100000000, 100200000, 'Accounts Receivable', '2021-07-14', 1),
(4, 100000000, 100300000, 'Stock', '2021-07-14', 1),
(5, 100000000, 100400000, 'Supplies', '2021-07-14', 1),
(6, 100000000, 100500000, 'Equipment', '2021-07-14', 1),
(12, 200000000, 200100000, 'Loans', '2021-07-14', 1),
(13, 200000000, 200200000, 'Account Payable', '2021-07-14', 1),
(14, 200000000, 200300000, 'Wages Payable', '2021-07-14', 1),
(16, 300000000, 300100000, 'Cost of goods sold', '2021-07-14', 1),
(17, 400000000, 400100000, 'Owners Capital', '2021-07-14', 1),
(18, 400000000, 400200000, 'Owners Withdrawals', '2021-07-14', 1),
(19, 500000000, 500100000, 'Direct Expenses', '2021-07-14', 1),
(20, 500000000, 500200000, 'Other Expense', '2021-07-14', 1),
(21, 100000000, 100600000, 'Land or Building', '2021-07-14', 1),
(22, 200000000, 200500000, 'Cash', '2021-07-15', 1),
(25, 100000000, 100700000, 'Cash at Bank', '2021-08-05', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_account_lv2`
--

CREATE TABLE `tbl_account_lv2` (
  `id` int(11) NOT NULL,
  `parent_code` int(11) DEFAULT NULL,
  `sub_child1` int(11) DEFAULT NULL,
  `acode` int(11) DEFAULT NULL,
  `aname` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_account_lv2`
--

INSERT INTO `tbl_account_lv2` (`id`, `parent_code`, `sub_child1`, `acode`, `aname`, `created_date`, `created_by`) VALUES
(3, 500000000, 500100000, 500100200, 'Wages Expense', '2021-07-14', 1),
(5, 500000000, 500200000, 500200100, 'Utilities Expense', '2021-07-14', 1),
(6, 500000000, 500200000, 500200200, 'Rent Expense', '2021-07-14', 1),
(7, 300000000, 300100000, 300100100, 'Cash Sale', '2021-07-14', 1),
(8, 300000000, 300100000, 300100200, 'Credit Sale', '2021-07-14', 1),
(10, 500000000, 500100000, 500100400, 'Salary Expense', '2021-07-14', 1),
(12, 300000000, 300100000, 300100300, 'Lease Sale', '2021-07-15', 1),
(17, 200000000, 200200000, 200200101, 'Naeem', '2021-08-04', 1),
(21, 200000000, 200200000, 200200102, 'Vendor 1', '2021-08-04', 1),
(22, 100000000, 100700000, 100700100, 'HBL Bank ', '2021-08-05', 1),
(23, 100000000, 100700000, 100700200, 'UBL Bank ', '2021-08-05', 1),
(24, 200000000, 200200000, 200200103, 'Haris', '2021-08-10', 1),
(25, 100000000, 100200000, 100200101, 'Adil', '2021-08-10', 1),
(26, 100000000, 100200000, 100200102, 'Talha', '2021-08-10', 1),
(28, 500000000, 500200000, 500200300, 'Transport Expense', '2021-08-17', 1),
(30, 400000000, 400100000, 400100100, 'Opening Balance Equity', '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_acode`
--

CREATE TABLE `tbl_acode` (
  `id` int(11) NOT NULL,
  `acode` int(11) NOT NULL,
  `aname` text NOT NULL,
  `atype` text NOT NULL,
  `effect` text DEFAULT NULL,
  `created_date` date NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_acode`
--

INSERT INTO `tbl_acode` (`id`, `acode`, `aname`, `atype`, `effect`, `created_date`, `created_by`) VALUES
(1, 100000000, 'Asset Accounts', 'Parent', 'None', '2021-07-14', 1),
(2, 200000000, 'Liability Accounts', 'Parent', 'None', '2021-07-14', 1),
(3, 300000000, 'Revenue Accounts', 'Parent', 'None', '2021-07-14', 1),
(4, 400000000, 'Equity Accounts', 'Parent', 'None', '2021-07-14', 1),
(5, 500000000, 'Expense Accounts', 'Parent', 'None', '2021-07-14', 1),
(6, 100100000, 'Cash', 'Child', 'Debit', '2021-07-14', 1),
(7, 100200000, 'Receivable', 'Child', 'Debit', '2021-07-14', 1),
(8, 100300000, 'Inventory', 'Child', 'Debit', '2021-07-14', 1),
(9, 100400000, 'Supplies', 'Child', 'Debit', '2021-07-14', 1),
(10, 100500000, 'Equipment', 'Child', 'Debit', '2021-07-14', 1),
(11, 100600000, 'Land or Building', 'Child', 'Debit', '2021-07-14', 1),
(12, 200100000, 'Loans', 'Child', 'Credit', '2021-07-14', 1),
(13, 200200000, 'Account Payable', 'Child', 'Credit', '2021-07-14', 1),
(14, 200300000, 'Wages Payable', 'Child', 'Credit', '2021-07-14', 1),
(15, 200400000, 'Unearned Revenues', 'Child', 'Credit', '2021-07-14', 1),
(16, 300100000, 'Sale\'s', 'Child', 'Credit', '2021-07-14', 1),
(17, 300100100, 'Cash Sale\'s', 'SubChild', 'Credit', '2021-07-14', 1),
(18, 300100200, 'Credit Sale\'s', 'SubChild', 'Credit', '2021-07-14', 1),
(19, 300100300, 'Lease Sale\'s', 'SubChild', 'Credit', '2021-07-14', 1),
(20, 400100000, 'Owner\'s Capital', 'Child', 'Credit', '2021-07-14', 1),
(21, 400200000, 'Owner\'s Withdrawals', 'Child', 'Debit', '2021-07-14', 1),
(22, 500100000, 'Direct Expense', 'Child', 'Debit', '2021-07-14', 1),
(23, 500200000, 'Other Expense', 'Child', 'Debit', '2021-07-14', 1),
(24, 500200100, 'Utilities Expense', 'SubChild', 'Debit', '2021-07-14', 1),
(25, 500200200, 'Rent Expense', 'SubChild', 'Debit', '2021-07-14', 1),
(26, 500100100, 'Supplies Expense', 'SubChild', 'Debit', '2021-07-14', 1),
(27, 500100200, 'Salary Expense', 'SubChild', 'Debit', '2021-07-14', 1),
(28, 500100300, 'Wages Expense', 'SubChild', 'Debit', '2021-07-14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank`
--

CREATE TABLE `tbl_bank` (
  `id` int(11) NOT NULL,
  `bank` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_bank`
--

INSERT INTO `tbl_bank` (`id`, `bank`) VALUES
(5, 'HABIB BANK LT'),
(6, 'ASKRI BANK');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cat`
--

CREATE TABLE `tbl_cat` (
  `id` int(11) NOT NULL,
  `cat_name` text DEFAULT NULL,
  `brand_id` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_cat`
--

INSERT INTO `tbl_cat` (`id`, `cat_name`, `brand_id`, `created_by`, `created_date`) VALUES
(3, 'Fans', '5', 1, '2021-07-15'),
(4, 'Refrigerator', '7', 1, '2021-07-15'),
(5, 'TV', '6', 1, '2021-07-15'),
(6, 'Mobiles/Tablet', '2', 1, '2021-07-15'),
(8, 'LCD', '4', 1, '2021-07-15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_catagory`
--

CREATE TABLE `tbl_catagory` (
  `id` int(11) NOT NULL,
  `cat_name` text DEFAULT NULL,
  `cat_image` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_catagory`
--

INSERT INTO `tbl_catagory` (`id`, `cat_name`, `cat_image`, `created_date`, `created_by`) VALUES
(2, 'Samsung', 'uploads/catagory/9851289131626168582.jpg', '2021-07-15', 0),
(4, 'Orient', 'uploads/catagory/20028480461626168862.png', '2021-07-13', 0),
(5, 'Asia', 'uploads/catagory/6070138321626168874.png', '2021-07-13', 0),
(6, 'TCL', 'uploads/catagory/13675797091626168919.png', '2021-07-13', 0),
(7, 'Haier', 'uploads/catagory/12215081721626168938.png', '2021-07-13', 1),
(10, 'Pell', NULL, '2021-07-15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE `tbl_company` (
  `comp_id` int(11) NOT NULL,
  `c_name` text DEFAULT NULL,
  `c_email` text DEFAULT NULL,
  `c_mobile` text DEFAULT NULL,
  `c_phone` text DEFAULT NULL,
  `user_profile` text DEFAULT NULL,
  `c_address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`comp_id`, `c_name`, `c_email`, `c_mobile`, `c_phone`, `user_profile`, `c_address`) VALUES
(1, 'Alkareem', 'Alkareem@gmail.com', '03402244271', '03402244271', 'uploads/company_img/12140707631626081798.png', 'RWP BHARIA TOWN');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `c_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `email` text DEFAULT NULL,
  `username` text DEFAULT NULL,
  `mobile_no1` text DEFAULT NULL,
  `mobile_no2` text DEFAULT NULL,
  `address_current` text DEFAULT NULL,
  `address_permanent` text DEFAULT NULL,
  `user_profile` text DEFAULT NULL,
  `gender` text DEFAULT NULL,
  `client_cnic` text DEFAULT NULL,
  `client_fathername` text DEFAULT NULL,
  `client_residential` text DEFAULT NULL,
  `client_occupation` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`c_id`, `customer_id`, `email`, `username`, `mobile_no1`, `mobile_no2`, `address_current`, `address_permanent`, `user_profile`, `gender`, `client_cnic`, `client_fathername`, `client_residential`, `client_occupation`, `created_by`, `created_date`) VALUES
(3, 100200101, 'adil@gmail.com', 'Adil', '0300-0882001', '0351-4630032', 'STR', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', 'uploads/userprofiles/21120669581628599728.jpg', 'Male', '51321-6853210-6', 'Hussain', 'Personal', 'Software Engineer', 1, '2021-08-10'),
(4, 100200102, 'talha@gmail.com', 'Talha', '0300-0882001', '0300-0882001', 'st 31', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', NULL, 'Other', '21312-3123123-1', 'Khaild', 'Personal', 'Software Engineer', 1, '2021-08-10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_expense`
--

CREATE TABLE `tbl_expense` (
  `id` int(11) NOT NULL,
  `expense` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_expense`
--

INSERT INTO `tbl_expense` (`id`, `expense`) VALUES
(7, 'EXPENSE #1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_head`
--

CREATE TABLE `tbl_head` (
  `id` int(11) NOT NULL,
  `acode` int(11) NOT NULL,
  `aname` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_head`
--

INSERT INTO `tbl_head` (`id`, `acode`, `aname`, `created_by`, `created_date`) VALUES
(1, 100000000, 'Asset Accounts', 1, '2021-07-14'),
(2, 200000000, 'Liability Accounts', 1, '2021-07-14'),
(4, 300000000, 'Revenue Accounts', 1, '2021-07-14'),
(5, 400000000, 'Equity Accounts', 1, '2021-07-14'),
(7, 500000000, 'Expense Accounts', 1, '2021-07-14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_installment`
--

CREATE TABLE `tbl_installment` (
  `plan_id` int(11) NOT NULL,
  `location` int(11) DEFAULT NULL,
  `customer` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `total_price` float DEFAULT NULL,
  `down_payment` float NOT NULL,
  `period` int(11) NOT NULL,
  `per_month_amount` float NOT NULL,
  `amount_recieved` text DEFAULT NULL,
  `gran1_name` text DEFAULT NULL,
  `gran1_fname` text DEFAULT NULL,
  `gran1_mobile_no` text DEFAULT NULL,
  `gran1_client_cnic` text DEFAULT NULL,
  `gran1_relation` text DEFAULT NULL,
  `gran1_occup` text DEFAULT NULL,
  `gran2_name` text NOT NULL,
  `gran2_fname` text DEFAULT NULL,
  `gran2_mobile_no` text DEFAULT NULL,
  `gran2_client_cnic` text DEFAULT NULL,
  `gran2_relation` text DEFAULT NULL,
  `gran2_occup` text DEFAULT NULL,
  `gran3_name` text DEFAULT NULL,
  `gran3_fname` text DEFAULT NULL,
  `gran3_mobile_no` text DEFAULT NULL,
  `gran3_client_cnic` text DEFAULT NULL,
  `gran3_relation` text DEFAULT NULL,
  `gran3_occup` text DEFAULT NULL,
  `created_date` date NOT NULL,
  `created_by` int(11) NOT NULL,
  `installment_status` text DEFAULT NULL,
  `client_cnic` text DEFAULT NULL,
  `mobile_no1` text DEFAULT NULL,
  `client_mobile_no` text DEFAULT NULL,
  `client_email` text DEFAULT NULL,
  `client_address` text DEFAULT NULL,
  `sales_men` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `avo` text DEFAULT NULL,
  `mo` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_installment`
--

INSERT INTO `tbl_installment` (`plan_id`, `location`, `customer`, `item_id`, `total_price`, `down_payment`, `period`, `per_month_amount`, `amount_recieved`, `gran1_name`, `gran1_fname`, `gran1_mobile_no`, `gran1_client_cnic`, `gran1_relation`, `gran1_occup`, `gran2_name`, `gran2_fname`, `gran2_mobile_no`, `gran2_client_cnic`, `gran2_relation`, `gran2_occup`, `gran3_name`, `gran3_fname`, `gran3_mobile_no`, `gran3_client_cnic`, `gran3_relation`, `gran3_occup`, `created_date`, `created_by`, `installment_status`, `client_cnic`, `mobile_no1`, `client_mobile_no`, `client_email`, `client_address`, `sales_men`, `remarks`, `avo`, `mo`) VALUES
(1, 1, 100200101, 1001, 13000, 1000, 3, 4000, '8000', 'Haris', 'Nasir', '0300-0882001', '84621-3412389-5', 'Friend', 'Software Engineer', 'Bilal', 'Aslam', '0300-0882001', '84621-3089562-1', 'Brother', 'Driver', 'Naeem', 'Naeem Hassan', '0300-0882001', '86213-0848513-0', 'Cousin', 'Business Man', '2021-08-21', 1, 'Pending', '51321-6853210-6', NULL, '0300-0882001', 'adil@gmail.com', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '4', '', '3', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_installment_payment`
--

CREATE TABLE `tbl_installment_payment` (
  `payment_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `location` int(11) DEFAULT NULL,
  `customer` int(11) NOT NULL,
  `customer_cnic` text DEFAULT NULL,
  `customer_email` text DEFAULT NULL,
  `customer_address` text NOT NULL,
  `customer_phone` text NOT NULL,
  `sales_men` int(11) DEFAULT NULL,
  `avo` int(11) DEFAULT NULL,
  `mo` int(11) DEFAULT NULL,
  `per_month_amount` float NOT NULL,
  `item_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_installment_payment`
--

INSERT INTO `tbl_installment_payment` (`payment_id`, `plan_id`, `location`, `customer`, `customer_cnic`, `customer_email`, `customer_address`, `customer_phone`, `sales_men`, `avo`, `mo`, `per_month_amount`, `item_id`, `created_date`, `created_by`) VALUES
(1, 1, 1, 100200101, '51321-6853210-6', 'adil@gmail.com', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '0300-0882001', 4, 3, 2, 4000, 1001, '2021-09-01', 1),
(2, 1, 1, 100200101, '51321-6853210-6', 'adil@gmail.com', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '0300-0882001', 4, 3, 2, 4000, 1001, '2021-10-01', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_items`
--

CREATE TABLE `tbl_items` (
  `id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `brand_id` text DEFAULT NULL,
  `item_name` text DEFAULT NULL,
  `item_model` text DEFAULT NULL,
  `sub_category` text DEFAULT NULL,
  `category` text DEFAULT NULL,
  `item_image` text DEFAULT NULL,
  `item_description` text DEFAULT NULL,
  `created_date` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_items`
--

INSERT INTO `tbl_items` (`id`, `item_id`, `brand_id`, `item_name`, `item_model`, `sub_category`, `category`, `item_image`, `item_description`, `created_date`, `created_by`) VALUES
(1, 1001, '2', 'Note 10 fs', 'Model fs', '5', '6', 'uploads/items/12052661021626350036.jpg', '                                                                                                                                                                                                                                    ', '2021-07-15', 1),
(2, 1002, '4', 'LCD 1', '32- inch', '14', '8', 'uploads/items/2287682271626169217.png', '                                                                            ', '2021-07-15', 1),
(3, 1003, '5', 'Roof-fan', 'fz-1', '10', '3', 'uploads/items/12498777551626169256.png', '                                                                            ', '2021-07-15', 1),
(5, 1004, '6', 'Smart-tv', 'tv-332', '8', '5', 'uploads/items/4157777531626169290.png', '                                                                            ', '2021-07-15', 1),
(8, 1005, '7', 'Refrigerator 1', 'ref-123', '12', '4', 'uploads/items/10105669101626181664.jpg', 'Refrigerator 1                                                             ', '2021-07-15', 1),
(9, 1006, '2', 'Note 9 fs', 'FSD', '6', '6', 'uploads/items/8207714481626351029.jpg', '                                      ', '2021-07-15', 1),
(13, 1007, '2', 'Note 9 ', 'mod1', '6', '6', NULL, '                                                                                                                                                        ', '2021-08-02', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `id` int(11) NOT NULL,
  `location` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `total` text DEFAULT NULL,
  `payment_type` text DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`id`, `location`, `remarks`, `total`, `payment_type`, `payment_date`, `created_by`, `created_date`) VALUES
(2, 1, 'Opening Balance From Opening Equity Account', '500000.00', 'Cash_Receipt', '2021-08-21', 1, '2021-08-21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_period`
--

CREATE TABLE `tbl_period` (
  `id` int(11) NOT NULL,
  `months` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_period`
--

INSERT INTO `tbl_period` (`id`, `months`, `created_date`, `created_by`) VALUES
(2, '3', '2021-08-21', 1),
(3, '5', '2021-08-21', 1),
(4, '7', '2021-08-21', 1),
(5, '9', '2021-08-21', 1),
(6, '12', '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchase`
--

CREATE TABLE `tbl_purchase` (
  `purchase_id` int(11) NOT NULL,
  `location` text DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `invoice_date` text DEFAULT NULL,
  `po_remarks` text DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `net_amount` float DEFAULT NULL,
  `gross_amount` float DEFAULT NULL,
  `amount_payed` float DEFAULT 0,
  `amount_remaining` float DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `bill_status` text DEFAULT NULL,
  `payment_status` text DEFAULT NULL,
  `bank_id` text DEFAULT NULL,
  `check_no` text DEFAULT NULL,
  `payment_method` text DEFAULT NULL,
  `item_total` int(11) DEFAULT NULL,
  `item_recieved` int(11) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `grn_date` text DEFAULT NULL,
  `payment_date` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_purchase`
--

INSERT INTO `tbl_purchase` (`purchase_id`, `location`, `invoice_no`, `invoice_date`, `po_remarks`, `vendor_id`, `net_amount`, `gross_amount`, `amount_payed`, `amount_remaining`, `discount`, `bill_status`, `payment_status`, `bank_id`, `check_no`, `payment_method`, `item_total`, `item_recieved`, `created_date`, `created_by`, `grn_date`, `payment_date`) VALUES
(1, '1', 'Invoice 1', '2021-08-21', 'testing', 200200101, 200000, 200000, 200000, 0, 0, 'Completed', 'Completed', '', '', 'Cash Payment', 20, 20, '2021-08-21', 1, '2021-08-21', '2021-08-21'),
(2, '1', 'Invoice 2', '2021-08-21', '', 200200101, 50000, 50000, 50000, 0, 0, 'Completed', 'Completed', '', '', 'Cash Payment', 10, 10, '2021-08-21', 1, '2021-08-21', '2021-08-21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchase_detail`
--

CREATE TABLE `tbl_purchase_detail` (
  `id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `invoice_no` text NOT NULL,
  `product` text NOT NULL,
  `qty` int(11) NOT NULL,
  `qty_rec` int(11) DEFAULT NULL,
  `item_serial` text DEFAULT NULL,
  `barcode` text DEFAULT NULL,
  `rate` float NOT NULL,
  `amount` float NOT NULL,
  `created_date` date NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_purchase_detail`
--

INSERT INTO `tbl_purchase_detail` (`id`, `purchase_id`, `invoice_no`, `product`, `qty`, `qty_rec`, `item_serial`, `barcode`, `rate`, `amount`, `created_date`, `created_by`) VALUES
(9, 1, 'Purchase_1', '1001', 20, 20, '1234', '986265432', 10000, 200000, '2021-08-21', 1),
(12, 2, 'Purchase_2', '1003', 10, 10, '123123', '23568978', 5000, 50000, '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchase_return`
--

CREATE TABLE `tbl_purchase_return` (
  `purchase_return_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `location` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `po_remarks` text DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `net_amount` float DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `amount_received` float DEFAULT NULL,
  `payment_method` text DEFAULT NULL,
  `bank_id` text DEFAULT NULL,
  `check_no` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_purchase_return`
--

INSERT INTO `tbl_purchase_return` (`purchase_return_id`, `purchase_id`, `location`, `invoice_no`, `invoice_date`, `po_remarks`, `vendor_id`, `net_amount`, `discount`, `amount_received`, `payment_method`, `bank_id`, `check_no`, `created_date`, `created_by`) VALUES
(1, 1, 1, 'Purchase_Return_1', '2021-08-21', 'testing', 200200101, 200000, 0, 100000, 'Cash Payment', '', '', '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchase_return_detail`
--

CREATE TABLE `tbl_purchase_return_detail` (
  `id` int(11) NOT NULL,
  `purchase_return_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `product` text DEFAULT NULL,
  `return_qty` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `rate` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `return_amount` float DEFAULT NULL,
  `item_serial` text DEFAULT NULL,
  `barcode` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_purchase_return_detail`
--

INSERT INTO `tbl_purchase_return_detail` (`id`, `purchase_return_id`, `purchase_id`, `product`, `return_qty`, `qty`, `rate`, `amount`, `return_amount`, `item_serial`, `barcode`, `created_date`, `created_by`) VALUES
(1, 1, 1, '1001', 10, 20, 10000, 200000, 100000, '1234', '986265432', '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sale`
--

CREATE TABLE `tbl_sale` (
  `sale_id` int(11) NOT NULL,
  `location` int(11) DEFAULT NULL,
  `sale_type` varchar(255) DEFAULT NULL,
  `sales_men` int(11) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_address` varchar(255) DEFAULT NULL,
  `customer_phone` varchar(255) DEFAULT NULL,
  `customer_cnic` text DEFAULT NULL,
  `customer_email` text DEFAULT NULL,
  `net_amount` float DEFAULT NULL,
  `gross_amount` float DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `amount_recieved` float DEFAULT NULL,
  `amount_remaining` float DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_sale`
--

INSERT INTO `tbl_sale` (`sale_id`, `location`, `sale_type`, `sales_men`, `customer_name`, `customer_address`, `customer_phone`, `customer_cnic`, `customer_email`, `net_amount`, `gross_amount`, `discount`, `amount_recieved`, `amount_remaining`, `remarks`, `created_date`, `created_by`) VALUES
(3, 1, 'Cash', 4, '100200101', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '0300-0882001', '51321-6853210-6', 'adil@gmail.com', 20000, 20000, 0, 20000, NULL, '', '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salesmen`
--

CREATE TABLE `tbl_salesmen` (
  `s_id` int(11) NOT NULL,
  `email` text DEFAULT NULL,
  `username` text DEFAULT NULL,
  `designation` text DEFAULT NULL,
  `mobile_no1` text DEFAULT NULL,
  `mobile_no2` text DEFAULT NULL,
  `address_current` text DEFAULT NULL,
  `address_permanent` text DEFAULT NULL,
  `user_profile` text DEFAULT NULL,
  `gender` text DEFAULT NULL,
  `salemen_cnic` text DEFAULT NULL,
  `salemen_fathername` int(11) DEFAULT NULL,
  `salemen_residential` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_salesmen`
--

INSERT INTO `tbl_salesmen` (`s_id`, `email`, `username`, `designation`, `mobile_no1`, `mobile_no2`, `address_current`, `address_permanent`, `user_profile`, `gender`, `salemen_cnic`, `salemen_fathername`, `salemen_residential`, `created_by`, `created_date`) VALUES
(2, 'yasir@gmail.com', 'Yasir2', 'MO', '0300-0882001', '0345-6465415', 'st 8', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', 'uploads/salesmen/5730300141628604292.jpg', 'Male', '56465-4654654-5', 0, 'Personal', 1, '2021-08-12'),
(3, 'zain@gmail.com', 'Zain', 'AVO', '0300-0882001', '0363-2230665', 'street 31', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', 'uploads/salesmen/4091136761628754176.jpg', 'Male', '98645-3120532-7', 0, 'Personal', 1, '2021-08-12'),
(4, 'atif@gmail.com', 'Atif', 'Salesman', '0300-0882001', '0354-2103520', 'Test 123', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', NULL, 'Male', '65310-8645326-8', 0, 'Rent', 1, '2021-08-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sale_detail`
--

CREATE TABLE `tbl_sale_detail` (
  `id` int(11) NOT NULL,
  `sale_id` text DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `product` text DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `s_rate` float DEFAULT NULL,
  `s_amount` float NOT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_sale_detail`
--

INSERT INTO `tbl_sale_detail` (`id`, `sale_id`, `invoice_no`, `product`, `qty`, `s_rate`, `s_amount`, `created_date`, `created_by`) VALUES
(10, '3', 'Sale_3', '1001', 1, 10000, 10000, '2021-08-21', 1),
(11, '3', 'Sale_3', '1003', 2, 5000, 10000, '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sale_return`
--

CREATE TABLE `tbl_sale_return` (
  `sale_return_id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `location` int(11) DEFAULT NULL,
  `sale_type` text DEFAULT NULL,
  `sales_men` int(11) DEFAULT NULL,
  `customer_name` text DEFAULT NULL,
  `customer_address` text DEFAULT NULL,
  `customer_phone` text DEFAULT NULL,
  `customer_cnic` text DEFAULT NULL,
  `customer_email` text DEFAULT NULL,
  `net_amount` float DEFAULT NULL,
  `amount_returned` float DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_sale_return`
--

INSERT INTO `tbl_sale_return` (`sale_return_id`, `sale_id`, `location`, `sale_type`, `sales_men`, `customer_name`, `customer_address`, `customer_phone`, `customer_cnic`, `customer_email`, `net_amount`, `amount_returned`, `remarks`, `created_date`, `created_by`) VALUES
(1, 3, 1, 'Cash', 4, '100200101', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '0300-0882001', '51321-6853210-6', 'adil@gmail.com	', 20000, 10000, '', '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sale_return_detail`
--

CREATE TABLE `tbl_sale_return_detail` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `sale_return_id` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `product` text DEFAULT NULL,
  `returned_qty` text DEFAULT NULL,
  `qty` text DEFAULT NULL,
  `rate` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `return_amount` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_sale_return_detail`
--

INSERT INTO `tbl_sale_return_detail` (`id`, `sale_id`, `sale_return_id`, `invoice_no`, `product`, `returned_qty`, `qty`, `rate`, `amount`, `return_amount`, `created_date`, `created_by`) VALUES
(1, 3, 1, 'Sale_Return_3', '1001', '1', '1', 10000, 10000, '10000', '2021-08-21', 1),
(2, 3, 1, 'Sale_Return_3', '1003', '', '2', 5000, 10000, '', '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sub_cat`
--

CREATE TABLE `tbl_sub_cat` (
  `id` int(11) NOT NULL,
  `cat_name` text DEFAULT NULL,
  `sub_cat_name` text DEFAULT NULL,
  `brand_id` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_sub_cat`
--

INSERT INTO `tbl_sub_cat` (`id`, `cat_name`, `sub_cat_name`, `brand_id`, `created_by`, `created_date`) VALUES
(5, '6', 'Note 10', '2', 1, '2021-07-15'),
(6, '6', 'Note 9', '2', 1, '2021-07-15'),
(7, '6', 'Note 8', '2', 1, '0000-00-00'),
(8, '5', '32 inch', '6', 1, '2021-07-15'),
(9, '5', '44 inch', '6', 1, '2021-07-15'),
(10, '3', 'Roof Fan', '5', 1, '2021-07-15'),
(11, '3', 'Water Cooler', '5', 1, '2021-07-15'),
(12, '4', 'Top-Freezer Refrigerator', '7', 1, '2021-07-15'),
(13, '4', 'Side-by-Side Refrigerator', '7', 1, '2021-07-15'),
(14, '8', 'Smart Tv', '4', 1, '2021-07-15'),
(15, '8', 'Non Smart TV', '4', 1, '2021-07-15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trans`
--

CREATE TABLE `tbl_trans` (
  `trans_id` int(11) NOT NULL,
  `vendor_id` text DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `account_id` text DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `narration` text DEFAULT NULL,
  `total_amount` float DEFAULT NULL,
  `amount_payed` float DEFAULT NULL,
  `amount_recieved` int(11) DEFAULT NULL,
  `v_type` text DEFAULT NULL,
  `bill_status` text DEFAULT NULL,
  `payment_status` text DEFAULT NULL,
  `bank_id` text DEFAULT NULL,
  `check_no` text DEFAULT NULL,
  `payment_method` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_trans`
--

INSERT INTO `tbl_trans` (`trans_id`, `vendor_id`, `customer_id`, `account_id`, `invoice_no`, `narration`, `total_amount`, `amount_payed`, `amount_recieved`, `v_type`, `bill_status`, `payment_status`, `bank_id`, `check_no`, `payment_method`, `created_date`, `created_by`) VALUES
(3, '200200101', NULL, NULL, 'Purchase_1', 'Amount Paid Against PO # 1 to Vendor , Net Amount was 200000.00 Amount Payed was 200000 Payment Date was 2021-08-21 GRN Date was 2021-08-21', 200000, 200000, NULL, 'CP', 'Completed', 'Completed', '', '', 'Cash Payment', '2021-08-21', 1),
(5, NULL, NULL, '400100100', 'Cash_Receipt_2', 'Balance Added', 500000, NULL, NULL, 'CR', 'Completed', NULL, NULL, NULL, 'Cash_Receipt', '2021-08-21', 1),
(7, '200200101', NULL, NULL, 'Purchase_2', 'Amount Paid Against PO # 2 to Vendor , Net Amount was 50000.00 Amount Payed was 50000 Payment Date was 2021-08-21 GRN Date was 2021-08-21', 50000, 50000, NULL, 'CP', 'Completed', 'Completed', '', '', 'Cash Payment', '2021-08-21', 1),
(12, NULL, 100200101, NULL, 'Installment_1', 'Down Payment Against Lease Sale # 1 is 1000 Total Amount was 13000 Per Month Istallment is 4000 Installment Period was 3 Yr Process Date was 2021-08-21 and Customer Name is Adil and Customer CNIC is 51321-6853210-6', 13000, NULL, 8000, 'CR', 'Completed', 'Pending', NULL, NULL, 'Cash', '2021-08-21', 1),
(13, NULL, 100200101, NULL, 'Sale_3', 'Total Amount Paid Against Sale # 3 is 20000 on Date 2021-08-21 and Customer Name is Adil and Customer CNIC is 51321-6853210-6', 20000, NULL, NULL, 'CR', 'Completed', NULL, NULL, NULL, 'Cash', '2021-08-21', 1),
(14, NULL, 100200101, NULL, 'Sale_Return_3', 'Total Amount Paid Against Sale Return # 3 is 10000 on Date 2021-08-21 and Customer CNIC is 51321-6853210-6', 10000, NULL, NULL, 'CP', 'Completed', NULL, NULL, NULL, 'Cash', '2021-08-21', 1),
(15, '200200101', NULL, NULL, 'Purchase_Return_1', 'Amount Recieved Against PO # 1 from Vendor , Net Amount was 200000.00 Amount Recieved was 100000 Payment Date was 2021-08-21  Complete Stock Returned on 2021-08-21', 100000, NULL, NULL, 'CR', 'Completed', NULL, '', '', 'Cash Payment', '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trans_detail`
--

CREATE TABLE `tbl_trans_detail` (
  `trans_detail_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `acode` text DEFAULT NULL,
  `d_amount` float DEFAULT NULL,
  `c_amount` float DEFAULT NULL,
  `bill_status` text DEFAULT NULL,
  `narration` text DEFAULT NULL,
  `created_date` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_trans_detail`
--

INSERT INTO `tbl_trans_detail` (`trans_detail_id`, `trans_id`, `invoice_no`, `acode`, `d_amount`, `c_amount`, `bill_status`, `narration`, `created_date`, `created_by`) VALUES
(9, 3, 'Purchase_1', '100300000', 200000, 0, 'Completed', ' PO # 1 Net Amount was 200000.00 Transaction Date was 2021-08-21  Complete Stock Received on 2021-08-21', '2021-08-21', 1),
(10, 3, 'Purchase_1', '200200101', 0, 200000, 'Completed', ' Payment Pending to Vendor against PO # 1 is 200000.00 Transaction Date was 2021-08-21', '2021-08-21', 1),
(13, 5, 'Cash_Receipt_2', '100100000', 500000, 0, NULL, 'Balance Added', '2021-08-21', 1),
(14, 5, 'Cash_Receipt_2', '400100100', 0, 500000, NULL, 'Balance Added', '2021-08-21', 1),
(15, 3, 'Purchase_1', '200200101', 200000, 0, 'Completed', ' Payment Cleared to Vendor against PO # 1 is 200000 Transaction Date was 2021-08-21', '2021-08-21', 1),
(16, 3, 'Purchase_1', '100100000', 0, 200000, 'Completed', ' Amount paid to Vendor against PO # 1 was 200000 Transaction Date was 2021-08-21  Complete Stock Received on 2021-08-21', '2021-08-21', 1),
(19, 7, 'Purchase_2', '100300000', 50000, 0, 'Completed', ' PO # 2 Net Amount was 50000.00 Transaction Date was 2021-08-21  Complete Stock Received on 2021-08-21', '2021-08-21', 1),
(20, 7, 'Purchase_2', '200200101', 0, 50000, 'Completed', ' Payment Pending to Vendor against PO # 2 is 50000.00 Transaction Date was 2021-08-21', '2021-08-21', 1),
(21, 7, 'Purchase_2', '200200101', 50000, 0, 'Completed', ' Payment Cleared to Vendor against PO # 2 is 50000 Transaction Date was 2021-08-21', '2021-08-21', 1),
(22, 7, 'Purchase_2', '100100000', 0, 50000, 'Completed', ' Amount paid to Vendor against PO # 2 was 50000 Transaction Date was 2021-08-21  Complete Stock Received on 2021-08-21', '2021-08-21', 1),
(31, 12, 'Installment_1', '300100300', 1000, 0, 'Pending', NULL, '2021-08-21', 1),
(32, 12, 'Installment_1', '100300000', 0, 13000, 'Pending', NULL, '2021-08-21', 1),
(33, 12, 'Installment_1', '100200101', 12000, 0, 'Pending', NULL, '2021-08-21', 1),
(34, 12, 'Installment_1', '300100300', 4000, 0, 'Pending', 'Installment Payment Against Lease Sale # 1 is 4000 For Month 1 and Process Date was 2021-09-01 and Customer CNIC is 51321-6853210-6', '2021-08-21', 1),
(35, 12, 'Installment_1', '100200101', 0, 4000, 'Pending', 'Payment Remaining against Lease Sale # 1 is 13000 and Customer CNIC is 51321-6853210-6', '2021-08-21', 1),
(36, 13, 'Sale_3', '300100100', 20000, 0, 'Completed', 'Total Amount Paid Against Sale # 3 is 20000 on Date 2021-08-21 and Customer Name is Adil and Customer CNIC is 51321-6853210-6', '2021-08-21', 1),
(37, 13, 'Sale_3', '100300000', 0, 20000, 'Completed', 'Total Amount Paid Against Sale # 3 is 20000 on Date 2021-08-21 and Customer Name is Adil and Customer CNIC is 51321-6853210-6', '2021-08-21', 1),
(38, 14, 'Sale_Return_3', '100300000', 10000, 0, 'Completed', 'Total Amount Paid Against Sale Return # 3 is 10000 on Date 2021-08-21 and Customer CNIC is 51321-6853210-6', '2021-08-21', 1),
(39, 14, 'Sale_Return_3', '300100100', 0, 10000, 'Completed', 'Total Amount Paid Against Sale Return # 3 is 10000 on Date 2021-08-21 and Customer CNIC is 51321-6853210-6', '2021-08-21', 1),
(40, 15, 'Purchase_Return_1', '100100000', 100000, 0, 'Completed', ' Amount Recieved from Vendor against PO # 1 was 100000 Transaction Date was 2021-08-21  Complete Stock Returned on 2021-08-21', '2021-08-21', 1),
(41, 15, 'Purchase_Return_1', '100300000', 0, 100000, 'Completed', ' Payment Cleared by Vendor against PO # 1 is 100000 Transaction Date was 2021-08-21', '2021-08-21', 1),
(42, 12, 'Installment_1', '300100300', 4000, 0, 'Pending', 'Installment Payment Against Lease Sale # 1 is 4000 For Month 1 and Process Date was 2021-10-01 and Customer CNIC is 51321-6853210-6', '2021-08-21', 1),
(43, 12, 'Installment_1', '100200101', 0, 4000, 'Pending', 'Payment Remaining against Lease Sale # 1 is 9000 and Customer CNIC is 51321-6853210-6', '2021-08-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendors`
--

CREATE TABLE `tbl_vendors` (
  `v_id` int(11) NOT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `username` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `mobile_no` text DEFAULT NULL,
  `user_profile` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_vendors`
--

INSERT INTO `tbl_vendors` (`v_id`, `vendor_id`, `username`, `email`, `address`, `mobile_no`, `user_profile`) VALUES
(10, 200200101, 'Naeem', 'naeem@gmail.com', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '03000882001', 'uploads/userprofiles/12740117131628069543.jpg'),
(14, 200200102, 'Vendor 1', 'vendor1@gmail.com', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '03000882001', 'uploads/userprofiles/2632357091628069567.jpg'),
(15, 200200103, 'Haris', 'haris.sultan51@gmail.com', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '03000882001', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` text NOT NULL,
  `user_email` text NOT NULL,
  `user_password` text NOT NULL,
  `user_privilege` text NOT NULL,
  `user_country` text DEFAULT NULL,
  `user_state` text DEFAULT NULL,
  `user_city` text DEFAULT NULL,
  `user_address` text DEFAULT NULL,
  `user_phone` text DEFAULT NULL,
  `user_birthday` date DEFAULT NULL,
  `user_gender` text DEFAULT NULL,
  `user_profile` text DEFAULT NULL,
  `contact_no` text DEFAULT NULL,
  `created_date` date NOT NULL,
  `permission` int(11) NOT NULL DEFAULT 0,
  `c_read` int(11) NOT NULL DEFAULT 0,
  `c_write` int(11) NOT NULL DEFAULT 0,
  `c_delete` int(11) NOT NULL DEFAULT 0,
  `s_read` int(11) NOT NULL DEFAULT 0,
  `s_write` int(11) NOT NULL DEFAULT 0,
  `s_delete` int(11) NOT NULL DEFAULT 0,
  `a_read` int(11) NOT NULL DEFAULT 0,
  `a_write` int(11) NOT NULL DEFAULT 0,
  `a_delete` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_password`, `user_privilege`, `user_country`, `user_state`, `user_city`, `user_address`, `user_phone`, `user_birthday`, `user_gender`, `user_profile`, `contact_no`, `created_date`, `permission`, `c_read`, `c_write`, `c_delete`, `s_read`, `s_write`, `s_delete`, `a_read`, `a_write`, `a_delete`) VALUES
(1, 'Main Branch', 'admin@gmail.com', '$2y$10$9H7.Iw1cG0v8eIrniik2Cu11oJw1wNgVZT6zEvtT8fwKLmH4GZ2YO', 'superadmin', 'PK', 'islamabad', 'islamabad', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '03000882001', '0000-00-00', 'male', 'uploads/Profiles/13576482481625145883.jpg', NULL, '2021-07-01', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
(3, 'Manager ', 'manager@gmail.com', '$2y$10$j0qVXIA7Xr0bJs.5Pz834uRDerv0qlVwgVG4ZgJ4F99TiyeahNJBW', 'employee', 'PK', 'islamabad', 'islamabad', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '03001212121', '0000-00-00', 'male', 'uploads/Profiles/4063274761625145823.jpg', NULL, '2021-07-01', 1, 1, 0, 0, 1, 0, 0, 0, 0, 0),
(5, 'Salesman', 'salesman@gmail.com', '$2y$10$j0qVXIA7Xr0bJs.5Pz834uRDerv0qlVwgVG4ZgJ4F99TiyeahNJBW', 'salesman', 'PK', 'islamabad', 'islamabad', 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '03000882001', '0000-00-00', 'male', 'uploads/Profiles/20364308771625220315.jpg', NULL, '2021-07-02', 1, 0, 0, 0, 1, 1, 1, 0, 0, 0),
(7, 'Lahore Branch', 'branch1@gmail.com', '$2y$10$mIyL05uaMl0FukAftBWlVuRau59z4FjGAi3xOVTcBwvD4ZeGOjKVi', 'branch', NULL, NULL, NULL, 'Address  Plot No -33 Riaz Business Center  Business Park Gulburg Greens Gulbarg Islamabad  Pakistan', '03000882001', NULL, NULL, NULL, '0352689898', '2021-08-12', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_account`
--
ALTER TABLE `tbl_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_account_lv2`
--
ALTER TABLE `tbl_account_lv2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_acode`
--
ALTER TABLE `tbl_acode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cat`
--
ALTER TABLE `tbl_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_catagory`
--
ALTER TABLE `tbl_catagory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_company`
--
ALTER TABLE `tbl_company`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tbl_expense`
--
ALTER TABLE `tbl_expense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_head`
--
ALTER TABLE `tbl_head`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_installment`
--
ALTER TABLE `tbl_installment`
  ADD PRIMARY KEY (`plan_id`);

--
-- Indexes for table `tbl_installment_payment`
--
ALTER TABLE `tbl_installment_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tbl_items`
--
ALTER TABLE `tbl_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_period`
--
ALTER TABLE `tbl_period`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_purchase`
--
ALTER TABLE `tbl_purchase`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `tbl_purchase_detail`
--
ALTER TABLE `tbl_purchase_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_purchase_return`
--
ALTER TABLE `tbl_purchase_return`
  ADD PRIMARY KEY (`purchase_return_id`);

--
-- Indexes for table `tbl_purchase_return_detail`
--
ALTER TABLE `tbl_purchase_return_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sale`
--
ALTER TABLE `tbl_sale`
  ADD PRIMARY KEY (`sale_id`);

--
-- Indexes for table `tbl_salesmen`
--
ALTER TABLE `tbl_salesmen`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `tbl_sale_detail`
--
ALTER TABLE `tbl_sale_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sale_return`
--
ALTER TABLE `tbl_sale_return`
  ADD PRIMARY KEY (`sale_return_id`);

--
-- Indexes for table `tbl_sale_return_detail`
--
ALTER TABLE `tbl_sale_return_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sub_cat`
--
ALTER TABLE `tbl_sub_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_trans`
--
ALTER TABLE `tbl_trans`
  ADD PRIMARY KEY (`trans_id`);

--
-- Indexes for table `tbl_trans_detail`
--
ALTER TABLE `tbl_trans_detail`
  ADD PRIMARY KEY (`trans_detail_id`);

--
-- Indexes for table `tbl_vendors`
--
ALTER TABLE `tbl_vendors`
  ADD PRIMARY KEY (`v_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_account`
--
ALTER TABLE `tbl_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_account_lv2`
--
ALTER TABLE `tbl_account_lv2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbl_acode`
--
ALTER TABLE `tbl_acode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_cat`
--
ALTER TABLE `tbl_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_catagory`
--
ALTER TABLE `tbl_catagory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_company`
--
ALTER TABLE `tbl_company`
  MODIFY `comp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_expense`
--
ALTER TABLE `tbl_expense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_head`
--
ALTER TABLE `tbl_head`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_installment`
--
ALTER TABLE `tbl_installment`
  MODIFY `plan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_installment_payment`
--
ALTER TABLE `tbl_installment_payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_items`
--
ALTER TABLE `tbl_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_period`
--
ALTER TABLE `tbl_period`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_purchase`
--
ALTER TABLE `tbl_purchase`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_purchase_detail`
--
ALTER TABLE `tbl_purchase_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_purchase_return`
--
ALTER TABLE `tbl_purchase_return`
  MODIFY `purchase_return_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_purchase_return_detail`
--
ALTER TABLE `tbl_purchase_return_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_sale`
--
ALTER TABLE `tbl_sale`
  MODIFY `sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_salesmen`
--
ALTER TABLE `tbl_salesmen`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_sale_detail`
--
ALTER TABLE `tbl_sale_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_sale_return`
--
ALTER TABLE `tbl_sale_return`
  MODIFY `sale_return_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_sale_return_detail`
--
ALTER TABLE `tbl_sale_return_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_sub_cat`
--
ALTER TABLE `tbl_sub_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_trans`
--
ALTER TABLE `tbl_trans`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_trans_detail`
--
ALTER TABLE `tbl_trans_detail`
  MODIFY `trans_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tbl_vendors`
--
ALTER TABLE `tbl_vendors`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
