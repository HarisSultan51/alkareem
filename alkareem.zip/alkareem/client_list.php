<!doctype html>
<html lang="en">

<?php
error_reporting(0);
include "includes/session.php";
include "includes/config.php";
include "includes/head.php";
include "user_permission.php";

session_start();

if(isset($_SESSION['adminid'])){


}
else{
   header('Location: login.php'); 
}
?>
<body class="theme-orange">

<!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30"><img src="https://wrraptheme.com/templates/lucid/hr/html/assets/images/logo-icon.svg" width="48" height="48" alt="Lucid"></div>
        <p>Please wait...</p>        
    </div>
</div>
<!-- Overlay For Sidebars -->

<div id="wrapper">

    <?php
include "includes/navbar.php";

include "includes/sidebar.php";
?>
    
   

    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">

                    <div class="col-lg-6 col-md-8 col-sm-12">                        
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Clients</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>                            
                            <li class="breadcrumb-item">Clients</li>
                            <li class="breadcrumb-item active">List</li>
                            <?php if($c_write=='1'){?><li class="breadcrumb-item "><a href="add_clients.php">
                                <button class="btn btn-sm btn-primary">Add Clients</button></a>  </li><?php }?>
                        </ul>
                    </div>            
                    <?php include "includes/graph.php";?>
                </div>
            </div>
            <?php
              
              if(isset($_GET['add']) && $_GET['add']=='successful' ){
                  ?>
                  <div class="alert alert-success" id="success-alert">
  
  <strong>Great!</strong> Client Added Succesfully.
</div>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#success-alert").hide();

    $("#success-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#success-alert").slideUp(500);
    });
  });
    </script>
            
              <?php
              }?>
                 <?php
              
              if(isset($_GET['add']) && $_GET['add']=='unsuccessful' ){
                  ?>
                  <div class="alert alert-danger" id="success-alert">
  
  <strong>Sorry!</strong> Client Not Added.
</div>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#success-alert").hide();

    $("#success-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#success-alert").slideUp(500);
    });
  });
    </script>
            
              <?php
              }?>

                                      <?php
              
              if(isset($_GET['update']) && $_GET['update']=='successful' ){
                  ?>
                  <div class="alert alert-success" id="success-alert">
  
  <strong>Great!</strong> Client Updated Succesfully.
</div>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#success-alert").hide();

    $("#success-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#success-alert").slideUp(500);
    });
  });
    </script>
            
              <?php
              }
             
                      if(isset($_GET['delete']) && $_GET['delete']=='successfull' ){
                  ?>
                  <div class="alert alert-danger" id="success-alert">
  
  <strong>Great!</strong> Client Deleted Succesfully.
</div>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#success-alert").hide();

    $("#success-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#success-alert").slideUp(500);
    });
  });
    </script>
            
              <?php
              }

              if(isset($_GET['update']) && $_GET['update']=='unsuccessful' ){
                  ?>
                  <div class="alert alert-danger" id="danger-alert">
  
  <strong>Opps!</strong>Failed to Update.
</div>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#danger-alert").hide();

    $("#danger-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#danger-alert").slideUp(500);
    });
  });
    </script>
    <?php
              }
              ?>
<?php
              

              if(isset($_GET['delete']) && $_GET['delete']=='unsuccessful'){
                  ?>
                  <div class="alert alert-danger" id="danger-alert">
  
  <strong>Opps!</strong>Failed to Delete Customer, Because Data related to Customer Exist in Transactions..!
</div>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#danger-alert").hide();

    $("#danger-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#danger-alert").slideUp(500);
    });
  });
    </script>
            
              <?php
              }
             ?>
             <?php
              

              if(isset($_GET['blocked']) && $_GET['blocked']=='successful'){
                  ?>
                  <div class="alert alert-success" id="danger-alert">
  
  <strong>Well !</strong> Customer has been Blocked!
</div>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#danger-alert").hide();

    $("#danger-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#danger-alert").slideUp(500);
    });
  });
    </script>
            
              <?php
              }
             ?>
              <?php
              

              if(isset($_GET['unblocked']) && $_GET['unblocked']=='successful'){
                  ?>
                  <div class="alert alert-success" id="danger-alert">
  
  <strong>Great !</strong> Customer has been Unblocked!
</div>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
  $("#danger-alert").hide();

    $("#danger-alert").fadeTo(4000, 500).slideUp(500, function() {
      $("#danger-alert").slideUp(500);
    });
  });
    </script>
            
              <?php
              }
             ?>
            <div class="row clearfix">
                <?php
                                $count=1;
                                $sql=mysqli_query($conn, "SELECT user_privilege, created_by FROM users where user_id='$userid'");
                                $data = mysqli_fetch_assoc($sql);
                                $user_privilege=$data['user_privilege'];
                                $created_by=$data['created_by'];
                                if($user_privilege!='branch' && $created_by=='1')
                                {

                                  $team = mysqli_query($conn,"SELECT * FROM tbl_customer");
                                }
                                else
                                {
                                  $team = mysqli_query($conn,"SELECT * FROM tbl_customer  where parent_id='$userid'");
                                }
                        
                                while($pdata = mysqli_fetch_assoc($team))   
                                { 
                                    $customer_id=$pdata['customer_id'];
                                    $username=$pdata['username'];
                                    $image=$pdata['user_profile'];
                                    $email=$pdata['email'];
                                    $mobile_no=$pdata['mobile_no'];
                                    $blacklist=$pdata['blacklist'];
                                ?>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card">
                        <div class="body text-center">
                            <div class="chart easy-pie-chart-1" data-percent="75"> <span><img src="<?php if($image!=''){ echo $image;}else{?> assets/images/userdefault.jpg<?php }?>" alt="user" class="rounded-circle"/></span> </div>
                            <h5><?php echo $username; ?> </h5>
                            <small><?php echo $email; ?></small>
                            <h6><?php  echo $mobile_no;?></h6>
                             <?php if($c_write=='1'){?>
                            <div class="m-t-15">
                                <a href="add_clients.php?edit_id=<?php echo $customer_id;?>">
                                <button class="btn btn-sm btn-primary">View Profile</button></a> 
                                <?php if($blacklist==0){?> 
                                <a href="operations/blocklist.php?block_id=<?php echo $customer_id;?>">
                                <button class="btn btn-sm btn-danger">Block</button></a>  
                                <?php }?>
                                <?php if($blacklist==1){?> 
                                <a href="operations/blocklist.php?unblock_id=<?php echo $customer_id;?>">
                                <button class="btn btn-sm btn-warning">Unblock</button></a>  
                                <?php }?>
                                 <a href="operations/delete_client.php?c_id=<?php echo $customer_id;?>">  
                                <button class="btn btn-sm btn-success">Delete</button></a>
                            </div>
                          <?php }?>
                            <ul class="social-links list-unstyled">
                                <li><a title="facebook"href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
                                <li><a title="twitter"href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                                <li><a title="instagram"href="javascript:void(0);"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php }?>
    </div>
    
</div>


<!-- Javascript -->
<script src="assets_light/bundles/libscripts.bundle.js"></script>    
<script src="assets_light/bundles/vendorscripts.bundle.js"></script>

<script src="assets_light/bundles/easypiechart.bundle.js"></script> <!-- easypiechart Plugin Js -->

<script src="assets_light/bundles/mainscripts.bundle.js"></script>
</body>

<!-- Mirrored from wrraptheme.com/templates/lucid/hr/html/light/client-list.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Jun 2021 09:01:14 GMT -->
</html>
